#ifndef CAMERA_FRAME_H
#define CAMERA_FRAME_H

#include <stdint.h>

// 函数简介     相机初始化成功后包装原 CSI 回调，保留原双缓冲行为
// 参数说明     void
// 返回参数     void
void camera_frame_install(void);

// 函数简介     领取一致的新帧快照，复制期间换帧时拒绝该快照
// 参数说明     destination     至少 188×120 字节；frame_id/capture_time_ms 为输出元数据
// 返回参数     uint8_t         成功 1，无新帧或快照失效 0
// 备注信息     整帧复制不关闭中断，时间来自完成回调
uint8_t camera_frame_take(uint8_t *destination, uint32_t *frame_id, uint32_t *capture_time_ms);

// 函数简介     读取消费前覆盖或复制竞争造成的丢帧计数
// 参数说明     void
// 返回参数     uint32_t        丢帧数，不统计正常重复读取
uint32_t camera_frame_dropped(void);

#endif
