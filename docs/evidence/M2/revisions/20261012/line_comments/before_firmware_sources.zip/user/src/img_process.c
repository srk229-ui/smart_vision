/*
 *@第十九届东南大学智能车竞赛基础四轮组部分开源学习代码
 */

#include "img_process.h"
#include <math.h>
#include <stddef.h>
#include <string.h>

#define VISION_MIN_WHITE_RUN (3)
#define VISION_RECONSTRUCTION_LIMIT (3u)
#define VISION_MIN_CONTROL_ROWS (3u)

static uint16_t reference_width[CONTROL_IMAGE_HEIGHT];
static uint8_t control_rows[CONTROL_BAND_COUNT] = {80u, 85u, 90u, 95u, 100u};
static float control_weights[CONTROL_BAND_COUNT] = {1.0f, 2.0f, 4.0f, 2.0f, 1.0f};
static int previous_seed = (int)CONTROL_IMAGE_WIDTH / 2;
static uint8_t reconstructed_frames;
static uint8_t previous_frame_present;
static VisionResult previous_result;

/* 每行选择距上一有效中点最近的连续白段，不把图像边框当作实测边界。 */
static uint8_t find_white_run(const uint8_t *row, int columns, int seed,
                             int *left, int *right)
{
    int column = 0, best_distance = columns + 1;
    uint8_t found = 0u;
    while (column < columns)
    {
        int start, end, distance;
        while (column < columns && row[column] != 255u)
            ++column;
        start = column;
        while (column < columns && row[column] == 255u)
            ++column;
        end = column - 1;
        if (end - start + 1 < VISION_MIN_WHITE_RUN)
            continue;
        distance = seed < start ? start - seed : (seed > end ? seed - end : 0);
        if (distance < best_distance)
        {
            *left = start;
            *right = end;
            best_distance = distance;
            found = 1u;
        }
    }
    return found;
}

static uint8_t clip_column(int column)
{
    if (column < 0)
        return 0u;
    if (column >= (int)CONTROL_IMAGE_WIDTH)
        return (uint8_t)(CONTROL_IMAGE_WIDTH - 1u);
    return (uint8_t)column;
}

void vision_reset(void)
{
    /* 新试验只清时间状态，保留人工标定宽度和已审核的控制带。 */
    previous_seed = (int)CONTROL_IMAGE_WIDTH / 2;
    reconstructed_frames = 0u;
    previous_frame_present = 0u;
    memset(&previous_result, 0, sizeof(previous_result));
}

uint8_t vision_set_reference_width(uint16_t row, uint16_t width)
{
    if (row >= CONTROL_IMAGE_HEIGHT ||
        (width != 0u && (width < VISION_MIN_WHITE_RUN || width >= CONTROL_IMAGE_WIDTH)))
        return 0u;
    reference_width[row] = width;
    return 1u;
}

uint8_t vision_set_control_band(const uint8_t rows[CONTROL_BAND_COUNT],
                                const float weights[CONTROL_BAND_COUNT])
{
    uint8_t index;
    float total = 0.0f;
    float normalized[CONTROL_BAND_COUNT];
    if (rows == NULL || weights == NULL)
        return 0u;
    for (index = 0u; index < CONTROL_BAND_COUNT; ++index)
    {
        if (rows[index] >= CONTROL_IMAGE_HEIGHT || !isfinite(weights[index]) ||
            weights[index] <= 0.0f || (index != 0u && rows[index] <= rows[index - 1u]))
            return 0u;
        total += weights[index];
    }
    if (!isfinite(total))
        return 0u;
    /* 先归一化再参与坐标加权，避免有限大权重乘像素坐标时溢出。 */
    for (index = 0u; index < CONTROL_BAND_COUNT; ++index)
    {
        normalized[index] = weights[index] / total;
        if (!isfinite(normalized[index]) || normalized[index] <= 0.0f)
            return 0u;
    }
    memcpy(control_rows, rows, sizeof(control_rows));
    memcpy(control_weights, normalized, sizeof(control_weights));
    return 1u;
}

uint8_t vision_process(const uint8_t *binary_after_otsu, uint32_t frame_id,
                       uint32_t capture_time_ms, VisionResult *result)
{
    int row, seed = previous_seed;
    uint8_t single_edge_present = 0u, contributing_rows = 0u, index;
    float weighted_middle = 0.0f, available_weight = 0.0f;
    float quality_weight = 0.0f, total_weight = 0.0f;
    if (result == NULL)
        return 0u;
    if (previous_frame_present != 0u && frame_id == previous_result.frame_id)
    {
        /* 重复帧不刷新采集时间，不延长单边重建许可。 */
        *result = previous_result;
        return result->valid;
    }
    memset(result, 0, sizeof(*result));
    result->frame_id = frame_id;
    result->capture_time_ms = capture_time_ms;
    result->track_lost = 1u;
    for (row = 0; row < (int)CONTROL_IMAGE_HEIGHT; ++row)
    {
        result->middle[row] = (uint8_t)(CONTROL_IMAGE_WIDTH / 2u);
        result->right[row] = (uint8_t)(CONTROL_IMAGE_WIDTH - 1u);
    }
    if (binary_after_otsu == NULL || (previous_frame_present != 0u &&
        (int32_t)(frame_id - previous_result.frame_id) <= 0))
        return 0u;

    for (row = (int)CONTROL_IMAGE_HEIGHT - 1; row >= 0; --row)
    {
        int left = 0, right = (int)CONTROL_IMAGE_WIDTH - 1, middle;
        uint8_t quality = 0u;
        if (find_white_run(binary_after_otsu + (size_t)row * CONTROL_IMAGE_WIDTH,
                           (int)CONTROL_IMAGE_WIDTH, seed, &left, &right) == 0u)
            continue;
        if (left > 0 && right < (int)CONTROL_IMAGE_WIDTH - 1)
        {
            /* 已标定时拒绝明显不符合赛道宽度的小白斑或错误白段。 */
            int measured_width = right - left;
            if (reference_width[row] == 0u ||
                (measured_width * 2 >= reference_width[row] &&
                 measured_width * 2 <= reference_width[row] * 3))
                quality = 2u;
        }
        else if ((left > 0 || right < (int)CONTROL_IMAGE_WIDTH - 1) &&
                 reference_width[row] != 0u)
        {
            single_edge_present = 1u;
            if (reconstructed_frames < VISION_RECONSTRUCTION_LIMIT)
            {
                /* 虚拟边界可在画面外；中点须在画面内，显示边界单独限幅。 */
                if (left == 0)
                    left = right - (int)reference_width[row];
                else
                    right = left + (int)reference_width[row];
                quality = 1u;
            }
        }
        middle = (left + right) / 2;
        if (quality == 0u || middle < 0 || middle >= (int)CONTROL_IMAGE_WIDTH)
            continue;
        result->left[row] = clip_column(left);
        result->right[row] = clip_column(right);
        result->middle[row] = (uint8_t)middle;
        result->row_quality[row] = quality;
        ++result->valid_rows;
        if (quality == 1u)
            ++result->reconstructed_rows;
        seed = middle;
    }
    if (single_edge_present != 0u)
    {
        if (reconstructed_frames < VISION_RECONSTRUCTION_LIMIT)
            ++reconstructed_frames;
    }
    else
        reconstructed_frames = 0u;

    for (index = 0u; index < CONTROL_BAND_COUNT; ++index)
    {
        uint8_t y = control_rows[index];
        float weight = control_weights[index];
        float effective_weight;
        total_weight += weight;
        if (result->row_quality[y] == 0u)
            continue;
        ++contributing_rows;
        /* 重建行同时降低转向贡献和置信度，按有效质量重新归一化中点。 */
        effective_weight = weight * (result->row_quality[y] == 2u ? 1.0f : 0.5f);
        available_weight += effective_weight;
        weighted_middle += effective_weight * result->middle[y];
        quality_weight += effective_weight;
    }
    result->confidence = quality_weight / total_weight;
    if (contributing_rows >= VISION_MIN_CONTROL_ROWS && available_weight > 0.0f &&
        result->confidence >= 0.35f)
    {
        result->error_px = (float)(CONTROL_IMAGE_WIDTH / 2u) - weighted_middle / available_weight;
        result->valid = 1u;
        result->track_lost = 0u;
        previous_seed = (int)(weighted_middle / available_weight);
    }
    previous_result = *result;
    previous_frame_present = 1u;
    return result->valid;
}

void binaryzation_process(unsigned char *_img, const unsigned short _rows,
                          const unsigned short _cols, const unsigned int _threshold_value)
{
    uint32_t index, size = (uint32_t)_rows * _cols;
    if (_img == NULL)
        return;
    for (index = 0u; index < size; ++index)
        _img[index] = _img[index] > _threshold_value ? 255u : 0u;
}

void get_hist_gram(unsigned char *_img, const unsigned short _rows,
                   const unsigned short _cols, uint32_t *_hist_gram)
{
    uint32_t index, size = (uint32_t)_rows * _cols;
    if (_hist_gram == NULL)
        return;
    /* 256 个计数全部清零，并允许大于 32767 的像素计数。 */
    memset(_hist_gram, 0, sizeof(uint32_t) * 256u);
    if (_img == NULL)
        return;
    for (index = 0u; index < size; ++index)
        ++_hist_gram[_img[index]];
}

unsigned char get_threshold_otsu(const uint32_t *_hist_gram)
{
    uint16_t gray;
    uint64_t count = 0u, integral = 0u, back_count = 0u, back_integral = 0u;
    double best_variance = -1.0;
    uint8_t threshold = 0u;
    if (_hist_gram == NULL)
        return 0u;
    for (gray = 0u; gray < 256u; ++gray)
    {
        count += _hist_gram[gray];
        integral += (uint64_t)_hist_gram[gray] * gray;
        if (_hist_gram[gray] != 0u)
            threshold = (uint8_t)gray;
    }
    if (count == 0u)
        return 0u;
    for (gray = 0u; gray < 255u; ++gray)
    {
        uint64_t fore_count;
        double delta, variance;
        back_count += _hist_gram[gray];
        back_integral += (uint64_t)_hist_gram[gray] * gray;
        if (back_count == 0u)
            continue;
        fore_count = count - back_count;
        if (fore_count == 0u)
            break;
        delta = (double)back_integral / (double)back_count -
                (double)(integral - back_integral) / (double)fore_count;
        variance = (double)back_count * (double)fore_count * delta * delta;
        if (variance > best_variance)
        {
            best_variance = variance;
            threshold = (uint8_t)gray;
        }
    }
    return threshold;
}

void auxiliary_process(uint8_t *_src_pixel_mat, uint8_t _src_rows, uint8_t _src_cols,
                        unsigned char _threshold_val, uint8_t *_left_line,
                        uint8_t *_mid_line, uint8_t *_right_line)
{
    int row, seed = _src_cols / 2;
    /* 兼容入口接收二值图，像素约定统一为 0/255，不重复使用灰度阈值。 */
    (void)_threshold_val;
    if (_src_pixel_mat == NULL || _left_line == NULL || _mid_line == NULL ||
        _right_line == NULL || _src_rows == 0u || _src_cols == 0u)
        return;
    for (row = (int)_src_rows - 1; row >= 0; --row)
    {
        int left = 0, right = _src_cols - 1;
        _left_line[row] = 0u;
        _right_line[row] = (uint8_t)(_src_cols - 1u);
        _mid_line[row] = (uint8_t)(_src_cols / 2u);
        if (find_white_run(_src_pixel_mat + (size_t)row * _src_cols, _src_cols,
                           seed, &left, &right) != 0u && left > 0 && right < _src_cols - 1)
        {
            _left_line[row] = (uint8_t)left;
            _right_line[row] = (uint8_t)right;
            _mid_line[row] = (uint8_t)((left + right) / 2);
            seed = _mid_line[row];
        }
    }
}

