#ifndef CONTROL_H
#define CONTROL_H

#include "control_types.h"

/* 操作返回 1 表示成功、0 表示拒绝；不会静默裁剪非法参数。 */

// 函数简介     安装平台短临界区回调，宿主单线程测试可不安装
// 参数说明     enter/leave     保存和恢复中断状态的配对函数
// 返回参数     void
void control_set_critical_hooks(uint32_t (*enter)(void), void (*leave)(uint32_t));

// 函数简介     初始化参数与状态，上电保持停止
// 参数说明     servo_center/min/max/direction    舵机初始配置，实车仍须标定
// 返回参数     void
void control_init(float servo_center, float servo_min, float servo_max, float servo_direction);

// 函数简介     设置编译配置允许的执行器输出，关闭时不能由参数重新开启
// 参数说明     motor_enabled/servo_enabled    非零允许对应输出
// 返回参数     void
void control_set_output_enabled(uint8_t motor_enabled, uint8_t servo_enabled);

// 函数简介     一致读取参数及版本
// 参数说明     params/version  输出指针，可为空
// 返回参数     void
void control_get_params(ControlParams *params, uint32_t *version);

// 函数简介     停止态原子应用整组参数并清积分
// 参数说明     params/expected_version    新参数及读取时的版本
// 返回参数     uint8_t         成功 1；非法、过期或运行中为 0
// 备注信息     改控制带后需要重新获得三帧可信图像，应用参数不解除故障
uint8_t control_apply_params(const ControlParams *params, uint32_t expected_version);

// 函数简介     提交人工启动请求，校验状态、标定和图像条件
// 参数说明     mode            TRACK 或最长八秒的架空 BENCH
// 返回参数     uint8_t         接受 1，拒绝 0
uint8_t control_request_run(ControlMode mode);

// 函数简介     请求停止并清输出、目标及积分，故障仍保持锁存
// 参数说明     void
// 返回参数     void
// 备注信息     真实 PWM 在下一个十毫秒任务写零，不等待速度斜坡
void control_request_stop(void);

// 函数简介     人工解除故障，不自动启动
// 参数说明     void
// 返回参数     uint8_t         接受 1；运行中或未经过停机周期为 0
uint8_t control_reset_fault(void);

// 函数简介     运行中通信异常时锁存故障
// 参数说明     void
// 返回参数     void
void control_report_link_fault(void);

// 函数简介     参数或模块接口不一致时锁存故障
// 参数说明     void
// 返回参数     void
void control_report_invalid_fault(void);

// 函数简介     发布新帧，按采集时间判断新鲜度，重复帧不计数
// 参数说明     vision          只读视觉结果
// 返回参数     void
void control_publish_vision(const VisionResult *vision);

// 函数简介     固定十毫秒采样、保护、PI和舵机输出计算
// 参数说明     measured_left/right    本周期编码器增量
// 返回参数     void
// 备注信息     调用者把输出快照施加到硬件，不在此处执行网络或显示
void control_tick(int16_t measured_left, int16_t measured_right);

// 函数简介     读取左右轮、真实量化 PWM、舵机和故障的一致快照
// 参数说明     snapshot        输出指针，可为空
// 返回参数     void
void control_get_snapshot(ControlSnapshot *snapshot);

// 函数简介     读取运行状态
// 参数说明     void
// 返回参数     ControlState    当前状态
ControlState control_get_state(void);

// 函数简介     读取十毫秒控制时基，支持无符号回绕差值
// 参数说明     void
// 返回参数     uint32_t        设备时间，单位毫秒
uint32_t control_now_ms(void);

#endif
