#include "control.h"
#include "pid.h"
#include <math.h>
#include <stddef.h>
#include <string.h>

static ControlParams config;
static ControlSnapshot current;
static uint32_t (*critical_enter)(void);
static void (*critical_leave)(uint32_t);
static volatile uint32_t device_ms;
static uint32_t run_start_ms;
static uint32_t last_good_ms;
static uint32_t last_frame_ms;
static uint32_t stop_sample;
static uint8_t motor_output_enabled;
static uint8_t servo_output_enabled;
static uint8_t good_frames;
static uint8_t lost_frames;
static uint8_t frame_seen;
static uint8_t good_seen;
static uint8_t derivative_ready;
static float previous_error;
static float steering_target;

static uint32_t lock_control(void)
{
    return critical_enter != NULL ? critical_enter() : 0u;
}

static void unlock_control(uint32_t key)
{
    if (critical_leave != NULL) critical_leave(key);
}

static float clamp_value(float value, float low, float high)
{
    return value < low ? low : (value > high ? high : value);
}

static float approach(float value, float target, float step)
{
    return value + clamp_value(target - value, -step, step);
}

static uint8_t in_range(float value, float low, float high)
{
    return (uint8_t)(isfinite(value) && value >= low && value <= high);
}

static uint8_t params_valid(const ControlParams *p)
{
    float weight_sum = 0.0f;
    uint8_t i;
    if (p == NULL || !in_range(p->target_left, 0.0f, 100.0f) ||
        !in_range(p->target_right, 0.0f, 100.0f) ||
        !in_range(p->kp_left, 0.0f, 1000.0f) || !in_range(p->kp_right, 0.0f, 1000.0f) ||
        !in_range(p->ki_left, 0.0f, 1000.0f) || !in_range(p->ki_right, 0.0f, 1000.0f) ||
        !in_range(p->pwm_max, 0.0f, 5000.0f) || p->pwm_max != floorf(p->pwm_max) ||
        !in_range(p->integral_max, 0.0f, p->pwm_max) ||
        !in_range(p->accel_counts_per_s, 1.0f, 1000.0f) ||
        !in_range(p->servo_min, 0.0f, 180.0f) || !in_range(p->servo_max, 0.0f, 180.0f) ||
        !in_range(p->servo_center, p->servo_min, p->servo_max) || p->servo_min >= p->servo_max ||
        !(p->servo_direction == -1.0f || p->servo_direction == 1.0f) ||
        !in_range(p->steer_kp, 0.0f, 5.0f) || !in_range(p->steer_kd, 0.0f, 5.0f) ||
        !in_range(p->servo_rate_deg_s, 1.0f, 360.0f) ||
        !in_range(p->curve_speed_factor, 0.1f, 1.0f) ||
        p->vision_timeout_ms != 100u || p->lost_frame_limit != 3u ||
        p->calibration_confirmed > 1u) return 0u;
    for (i = 0; i < CONTROL_BAND_COUNT; ++i)
    {
        if (p->look_rows[i] >= CONTROL_IMAGE_HEIGHT ||
            !in_range(p->look_weights[i], 0.001f, 100.0f) ||
            (i > 0u && p->look_rows[i] <= p->look_rows[i - 1u])) return 0u;
        weight_sum += p->look_weights[i];
    }
    return (uint8_t)(weight_sum > 0.0f);
}

static void reset_outputs(void)
{
    Pid_Reset(&speed_pid_l);
    Pid_Reset(&speed_pid_r);
    current.target_left = current.target_right = 0.0f;
    current.pwm_left = current.pwm_right = 0.0f;
    current.raw_pwm_left = current.raw_pwm_right = 0.0f;
    current.integral_left = current.integral_right = 0.0f;
    current.saturated_left = current.saturated_right = 0u;
    current.servo_enabled = 0u;
    current.servo_cmd = config.servo_center;
    steering_target = config.servo_center;
    derivative_ready = 0u;
    speed_target = speed_pwm = 0.0f;
}

static void latch_fault(ControlFault fault)
{
    current.state = CONTROL_FAULT;
    current.fault = fault;
    good_frames = 0u;
    reset_outputs();
    stop_sample = current.sample_id;
}

void control_set_critical_hooks(uint32_t (*enter)(void), void (*leave)(uint32_t))
{
    critical_enter = enter;
    critical_leave = leave;
}

//-------------------------------------------------------------------------------------------------------------------
// 函数简介     初始化运行状态和参数，上电保持停止
// 参数说明     servo_center/min/max/direction    人工待标定的舵机初始配置
// 返回参数     void
// 备注信息     启动前仍须由操作者确认标定，默认不会输出电机或舵机脉冲
//-------------------------------------------------------------------------------------------------------------------
void control_init(float servo_center, float servo_min, float servo_max, float servo_direction)
{
    static const uint8_t rows[CONTROL_BAND_COUNT] = {80u, 85u, 90u, 95u, 100u};
    static const float weights[CONTROL_BAND_COUNT] = {1.0f, 2.0f, 4.0f, 2.0f, 1.0f};
    uint8_t i;
    memset(&config, 0, sizeof(config));
    memset(&current, 0, sizeof(current));
    config.kp_left = config.kp_right = 50.0f;
    config.pwm_max = config.integral_max = 5000.0f;
    config.accel_counts_per_s = 50.0f;
    config.servo_center = servo_center;
    config.servo_min = servo_min;
    config.servo_max = servo_max;
    config.servo_direction = servo_direction;
    config.steer_kp = 0.5f;
    config.servo_rate_deg_s = 60.0f;
    config.curve_speed_factor = 0.5f;
    config.vision_timeout_ms = 100u;
    config.lost_frame_limit = 3u;
    for (i = 0; i < CONTROL_BAND_COUNT; ++i)
    {
        config.look_rows[i] = rows[i];
        config.look_weights[i] = weights[i];
    }
    device_ms = run_start_ms = last_good_ms = last_frame_ms = 0u;
    stop_sample = 0u;
    good_frames = lost_frames = frame_seen = good_seen = 0u;
    motor_output_enabled = servo_output_enabled = 0u;
    current.params_version = 1u;
    current.mode = CONTROL_MODE_TRACK;
    current.vision_age_ms = UINT32_MAX;
    Pid_Param_Init(&speed_pid_l, 50.0f, 0.0f, 0.0f, 5000.0f, 5000.0f);
    Pid_Param_Init(&speed_pid_r, 50.0f, 0.0f, 0.0f, 5000.0f, 5000.0f);
    current.state = params_valid(&config) ? CONTROL_READY : CONTROL_FAULT;
    current.fault = current.state == CONTROL_READY ? CONTROL_FAULT_NONE : CONTROL_FAULT_INVALID_VALUE;
    reset_outputs();
}

void control_set_output_enabled(uint8_t motor_enabled, uint8_t servo_enabled)
{
    uint32_t key = lock_control();
    motor_output_enabled = (uint8_t)(motor_enabled != 0u);
    servo_output_enabled = (uint8_t)(servo_enabled != 0u);
    if (!motor_output_enabled || (current.mode == CONTROL_MODE_TRACK && !servo_output_enabled))
    {
        if (current.state == CONTROL_RUNNING) current.state = CONTROL_READY;
        reset_outputs();
        stop_sample = current.sample_id;
    }
    unlock_control(key);
}

void control_get_params(ControlParams *params, uint32_t *version)
{
    uint32_t key = lock_control();
    if (params != NULL) *params = config;
    if (version != NULL) *version = current.params_version;
    unlock_control(key);
}

//-------------------------------------------------------------------------------------------------------------------
// 函数简介     停止态原子应用整组参数并发布新版本
// 参数说明     params          参数快照；expected_version 为读取时的版本
// 返回参数     uint8_t         成功为 1，运行中、过期或非法请求为 0
// 备注信息     应用参数后清积分；故障状态不会因此解除
//-------------------------------------------------------------------------------------------------------------------
uint8_t control_apply_params(const ControlParams *params, uint32_t expected_version)
{
    uint32_t key;
    if (!params_valid(params)) return 0u;
    key = lock_control();
    if (current.state == CONTROL_RUNNING || expected_version != current.params_version)
    {
        unlock_control(key);
        return 0u;
    }
    if (memcmp(config.look_rows, params->look_rows, sizeof(config.look_rows)) != 0 ||
        memcmp(config.look_weights, params->look_weights, sizeof(config.look_weights)) != 0)
    {
        good_frames = good_seen = derivative_ready = 0u;
    }
    config = *params;
    ++current.params_version;
    current.params_applied_ms = device_ms;
    Pid_Param_Init(&speed_pid_l, config.kp_left, config.ki_left, 0.0f, config.integral_max, config.pwm_max);
    Pid_Param_Init(&speed_pid_r, config.kp_right, config.ki_right, 0.0f, config.integral_max, config.pwm_max);
    speed_KP = config.kp_left;
    speed_KI = config.ki_left;
    speed_KD = 0.0f;
    speed_IMAX = config.integral_max;
    speed_OUTMAX = config.pwm_max;
    reset_outputs();
    unlock_control(key);
    return 1u;
}

uint8_t control_request_run(ControlMode mode)
{
    uint32_t key = lock_control();
    if (current.state != CONTROL_READY || !motor_output_enabled || !config.calibration_confirmed ||
        current.sample_id == stop_sample ||
        !(mode == CONTROL_MODE_TRACK || mode == CONTROL_MODE_BENCH) ||
        (config.target_left <= 0.0f && config.target_right <= 0.0f) ||
        (mode == CONTROL_MODE_TRACK && (!servo_output_enabled || good_frames < 3u || !good_seen ||
         (uint32_t)(device_ms - last_good_ms) > config.vision_timeout_ms)))
    {
        unlock_control(key);
        return 0u;
    }
    current.mode = mode;
    current.state = CONTROL_RUNNING;
    run_start_ms = device_ms;
    derivative_ready = 0u;
    unlock_control(key);
    return 1u;
}

void control_request_stop(void)
{
    uint32_t key = lock_control();
    if (current.state != CONTROL_FAULT) current.state = CONTROL_READY;
    reset_outputs();
    stop_sample = current.sample_id;
    unlock_control(key);
}

uint8_t control_reset_fault(void)
{
    uint32_t key = lock_control();
    if (current.state == CONTROL_RUNNING || current.sample_id == stop_sample || !params_valid(&config))
    {
        unlock_control(key);
        return 0u;
    }
    current.state = CONTROL_READY;
    current.fault = CONTROL_FAULT_NONE;
    good_frames = lost_frames = 0u;
    reset_outputs();
    unlock_control(key);
    return 1u;
}

void control_report_link_fault(void)
{
    uint32_t key = lock_control();
    if (current.state == CONTROL_RUNNING) latch_fault(CONTROL_FAULT_LINK);
    unlock_control(key);
}

void control_report_invalid_fault(void)
{
    uint32_t key = lock_control();
    latch_fault(CONTROL_FAULT_INVALID_VALUE);
    unlock_control(key);
}

//-------------------------------------------------------------------------------------------------------------------
// 函数简介     接收新帧结果，以采集时间而不是处理时间计算新鲜度
// 参数说明     vision          只读视觉结果，重复帧不参与计数和微分
// 返回参数     void
// 备注信息     同一帧仅更新一次舵机目标；实际变化率限制在十毫秒控制任务中执行
//-------------------------------------------------------------------------------------------------------------------
void control_publish_vision(const VisionResult *vision)
{
    uint32_t key;
    uint32_t frame_dt;
    uint8_t usable;
    if (vision == NULL) return;
    key = lock_control();
    if (frame_seen && (int32_t)(vision->frame_id - current.frame_id) <= 0)
    {
        unlock_control(key);
        return;
    }
    frame_dt = vision->capture_time_ms - last_frame_ms;
    last_frame_ms = vision->capture_time_ms;
    frame_seen = 1u;
    current.frame_id = vision->frame_id;
    current.threshold = vision->threshold;
    usable = (uint8_t)(vision->valid && !vision->track_lost &&
        in_range(vision->confidence, 0.3f, 1.0f) &&
        in_range(vision->error_px, -(float)CONTROL_IMAGE_WIDTH, (float)CONTROL_IMAGE_WIDTH) &&
        (uint32_t)(device_ms - vision->capture_time_ms) <= config.vision_timeout_ms);
    current.confidence = usable ? vision->confidence : 0.0f;
    if (usable)
    {
        float derivative = 0.0f;
        float command;
        current.vision_error_px = vision->error_px;
        last_good_ms = vision->capture_time_ms;
        good_seen = 1u;
        lost_frames = 0u;
        good_frames = vision->confidence >= 0.6f ? (uint8_t)(good_frames < 3u ? good_frames + 1u : 3u) : 0u;
        if (current.state == CONTROL_RUNNING && current.mode == CONTROL_MODE_TRACK)
        {
            if (derivative_ready && frame_dt > 0u && frame_dt <= config.vision_timeout_ms)
                derivative = (vision->error_px - previous_error) * 1000.0f / (float)frame_dt;
            command = config.servo_center - config.servo_direction *
                      (config.steer_kp * vision->error_px + config.steer_kd * derivative);
            if (!isfinite(command)) latch_fault(CONTROL_FAULT_INVALID_VALUE);
            else steering_target = clamp_value(command, config.servo_min, config.servo_max);
            previous_error = vision->error_px;
            derivative_ready = 1u;
        }
    }
    else
    {
        good_frames = 0u;
        derivative_ready = 0u;
        if (lost_frames < UINT8_MAX) ++lost_frames;
    }
    unlock_control(key);
}

//-------------------------------------------------------------------------------------------------------------------
// 函数简介     固定十毫秒执行采样、保护、目标斜坡、双轮 PI 和舵机限速
// 参数说明     measured_left/right    本周期带方向的编码器增量
// 返回参数     void
// 备注信息     不进行网络和显示；调用方必须把快照中的实际输出写入硬件
//-------------------------------------------------------------------------------------------------------------------
void control_tick(int16_t measured_left, int16_t measured_right)
{
    float factor = 1.0f;
    float dt_s = (float)CONTROL_PERIOD_MS / 1000.0f;
    device_ms += CONTROL_PERIOD_MS;
    ++current.sample_id;
    current.timestamp_ms = device_ms;
    current.measured_left = measured_left;
    current.measured_right = measured_right;
    current.vision_age_ms = good_seen ? device_ms - last_good_ms : UINT32_MAX;
    if (current.state == CONTROL_RUNNING && current.mode == CONTROL_MODE_TRACK)
    {
        if (!good_seen || current.vision_age_ms > config.vision_timeout_ms)
            latch_fault(CONTROL_FAULT_VISION_TIMEOUT);
        else if (lost_frames >= config.lost_frame_limit) latch_fault(CONTROL_FAULT_TRACK_LOST);
    }
    if (current.state == CONTROL_RUNNING && current.mode == CONTROL_MODE_BENCH &&
        (uint32_t)(device_ms - run_start_ms) >= CONTROL_BENCH_MAX_MS)
    {
        current.state = CONTROL_READY;
        reset_outputs();
    }
    if (current.state != CONTROL_RUNNING || !motor_output_enabled)
    {
        /* 停机每周期保持零输出，不让旧积分或速度斜坡推迟停止。 */
        Pid_Reset(&speed_pid_l);
        Pid_Reset(&speed_pid_r);
        current.target_left = current.target_right = 0.0f;
        current.pwm_left = current.pwm_right = 0.0f;
        current.raw_pwm_left = current.raw_pwm_right = 0.0f;
        current.integral_left = current.integral_right = 0.0f;
        current.saturated_left = current.saturated_right = 0u;
        current.servo_enabled = 0u;
        speed_target = speed_pwm = 0.0f;
        speed_real = (float)measured_right;
        return;
    }
    if (current.mode == CONTROL_MODE_TRACK)
    {
        float bend = clamp_value(fabsf(current.vision_error_px) / 30.0f, 0.0f, 1.0f);
        factor = 1.0f - bend * (1.0f - config.curve_speed_factor);
        if (current.confidence < 0.6f || lost_frames > 0u) factor = fminf(factor, 0.5f);
    }
    current.target_left = approach(current.target_left, config.target_left * factor, config.accel_counts_per_s * dt_s);
    current.target_right = approach(current.target_right, config.target_right * factor, config.accel_counts_per_s * dt_s);
    current.pwm_left = (float)(uint32_t)PidLocCtrl(&speed_pid_l, current.target_left - measured_left, dt_s);
    current.pwm_right = (float)(uint32_t)PidLocCtrl(&speed_pid_r, current.target_right - measured_right, dt_s);
    current.raw_pwm_left = speed_pid_l.out_raw;
    current.raw_pwm_right = speed_pid_r.out_raw;
    current.integral_left = speed_pid_l.out_i;
    current.integral_right = speed_pid_r.out_i;
    current.saturated_left = (uint8_t)(current.raw_pwm_left < 0.0f ||
        (config.pwm_max > 0.0f && current.pwm_left >= config.pwm_max));
    current.saturated_right = (uint8_t)(current.raw_pwm_right < 0.0f ||
        (config.pwm_max > 0.0f && current.pwm_right >= config.pwm_max));
    current.servo_enabled = servo_output_enabled;
    current.servo_cmd = approach(current.servo_cmd,
        current.mode == CONTROL_MODE_TRACK ? steering_target : config.servo_center,
        config.servo_rate_deg_s * dt_s);
    speed_target = current.target_right;
    speed_real = (float)measured_right;
    speed_pwm = current.pwm_right;
}

void control_get_snapshot(ControlSnapshot *snapshot)
{
    uint32_t key = lock_control();
    if (snapshot != NULL) *snapshot = current;
    unlock_control(key);
}

ControlState control_get_state(void)
{
    uint32_t key = lock_control();
    ControlState state = current.state;
    unlock_control(key);
    return state;
}

uint32_t control_now_ms(void)
{
    return device_ms;
}
