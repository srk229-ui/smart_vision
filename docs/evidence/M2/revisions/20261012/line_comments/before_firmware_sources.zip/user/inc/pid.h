#ifndef _PID_H
#define _PID_H

#include <stddef.h>
#include <stdint.h>

typedef struct
{
    float                kp;                    // 比例增益
    float                ki;                    // 按秒定义的积分增益
    float                kd;                    // 按秒定义的微分增益，速度环默认关闭
    float                imax;                  // 积分输出贡献的绝对值上限

    float                out_p;                 // 比例输出，增量式中为本周期增量
    float                out_i;                 // 积分输出，增量式中为本周期增量
    float                out_d;                 // 微分输出，增量式中为本周期增量
    float                out;                   // 实际输出，限制在零到 outmax
    float                out_raw;               // 限幅前输出，用于观测饱和
    float                outmax;                // 正向输出上限

    float                integrator;            // 位置式积分输出贡献，不保存未加权误差历史
    float                last_error;            // 上次误差
    float                last_derivative;       // 增量式使用的上次误差变化量
    unsigned long        last_t;                // 保留兼容字段，不用于计算采样周期
}pid_param_t;

extern pid_param_t speed_pid_l;  // 电机PID
extern pid_param_t speed_pid_r;  // 电机PID
extern float speed_KP, speed_KI,speed_KD, speed_IMAX, speed_OUTMAX;
extern float speed_target;                      // 目标速度，单位为每十毫秒编码器计数
extern float speed_real;                        // 兼容实际速度字段，单位同目标速度
extern float speed_pwm;                         // 兼容电机 PWM 输出字段


void My_Pid_Init(void);
void Pid_Param_Init(pid_param_t * pid, float kp, float ki, float kd, float imax, float outmax);

//-------------------------------------------------------------------------------------------------------------------
// 函数简介     清空控制历史，保留增益和限幅配置
// 参数说明     pid             控制器指针，空指针时直接返回
// 返回参数     void
// 备注信息     停机、故障和控制模式切换时调用，必须与控制中断同步
//-------------------------------------------------------------------------------------------------------------------
void Pid_Reset(pid_param_t *pid);

float constrain_float(float amt, float low, float high);
short constrain_short(short amt, short low, short high);


//-------------------------------------------------------------------------------------------------------------------
// 函数简介     带条件积分的正向位置式 PID，速度环使用本接口
// 参数说明     pid             控制器指针
// 参数说明     error           目标与反馈之差
// 参数说明     dt_s            采样周期，单位为秒，十毫秒应传入 0.010f
// 返回参数     float           实际正向输出；非法输入返回零并清空控制历史
// 备注信息     Ki 为零时清积分；积分输出限制在正负 imax，实际输出限制在零到 outmax
//-------------------------------------------------------------------------------------------------------------------
float PidLocCtrl(pid_param_t *pid, float error, float dt_s);

//-------------------------------------------------------------------------------------------------------------------
// 函数简介     保留兼容的正向增量式 PID
// 参数说明     pid             控制器指针，不能与位置式控制混用同一历史状态
// 参数说明     error           目标与反馈之差
// 参数说明     dt_s            采样周期，单位为秒
// 返回参数     float           实际正向输出；非法输入返回零并清空控制历史
// 备注信息     不用于主速度环；切换算法前先调用 Pid_Reset
//-------------------------------------------------------------------------------------------------------------------
float PidIncCtrl(pid_param_t *pid, float error, float dt_s);


#endif
