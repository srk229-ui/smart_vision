#include "main.h" // 所有引脚信息更改在main.h里改宏

// *************************** 例程硬件连接说明 ***************************
/*

            连接好电机、主板、驱动板、摄像头、编码器
            (请确保全部正确连接后在使用此例程，所有外设均会使用)
*/
// *************************** 例程测试说明 ***************************
/*
            本例程包含功能：
            1.初始化摄像头并采集图像进行大津法二值化
            2.初始化屏幕并显示关键信息
            3.加权视觉误差、置信度和有界舵机 P/PD 转向
            4.十毫秒双轮 PI、上电停止、人工启动与故障锁存


            注意！注意！注意！注意！
            注意！注意！注意！注意！
            注意！注意！注意！注意！

            1.请仔细阅读main.h的所有注释，确保所有宏都和自己的硬件连接对应
            2.若屏幕显示二值化后的图像有缺陷，可能不能正常走直线，
            可以自行更改二值化算法或找光环境良好且均匀的环境测试例程（例程不提供更多的二值化算法）

*/

// **************************** 代码区域 ****************************

// 舵机中位采用现有配置作为初始值，实车仍需人工标定。
const float servo_motor_duty_middle = SERVO_MOTOR_CENTER;

static uint8_t image[MT9V03X_H][MT9V03X_W];
static uint32_t hist_gram[256];
static VisionResult vision;

//-------------------------------------------------------------------------------------------------------------------
// 函数简介     初始化外设与控制层，上电保持 READY 和零输出
// 参数说明     void
// 返回参数     void
// 备注信息     联网和相机等待不启动电机；人工确认后才允许运行
//-------------------------------------------------------------------------------------------------------------------
void Init(void)
{
    /* 电机与舵机 */
    pwm_init(MOTOR1_PWM, 17000, 0);
    gpio_init(MOTOR1_DIR, GPO, MOTOR1_FORWARD_DIR_LEVEL, GPO_PUSH_PULL);
    pwm_init(MOTOR2_PWM, 17000, 0);
    gpio_init(MOTOR2_DIR, GPO, MOTOR2_FORWARD_DIR_LEVEL, GPO_PUSH_PULL);
    pwm_init(SERVO_MOTOR_PWM, SERVO_MOTOR_FREQ, 0);

    /* 控制与编码器 */
    control_set_critical_hooks(interrupt_global_disable, interrupt_global_enable);
    control_init(servo_motor_duty_middle,
                 MIN(SERVO_MOTOR_L_MAX, SERVO_MOTOR_R_MAX),
                 MAX(SERVO_MOTOR_L_MAX, SERVO_MOTOR_R_MAX), SERVO_DIR);
    control_set_output_enabled(MOTOR_ENABLE, SERVO_MOTOR_ENABLE);
    encoder_quad_init(ENCODER_1, ENCODER_1_A, ENCODER_1_B);
    encoder_quad_init(ENCODER_2, ENCODER_2_A, ENCODER_2_B);
    pit_ms_init(PIT_CH0, CONTROL_LOOP_PERIOD_MS);

    /* 显示与通信 */
    flash_init();
    tft180_init();
    wifi_assistant_init();

    /* 摄像头 */
    while (mt9v03x_init())
    {
        tft180_show_string(0, 16, "CAM RETRY");
        system_delay_ms(1000);
    }
    camera_frame_install();
    vision_reset();
    tft180_show_string(0, 16, "READY / STOP");
}

// 静止、居中的直道图像才能用于宽度标定，不能从合成默认值推断实车宽度。
static uint8_t calibrate_width(const ControlParams *params, const ControlSnapshot *snapshot)
{
    uint16_t row;
    uint16_t widths[CONTROL_IMAGE_HEIGHT];
    uint8_t i;
    if (snapshot->state == CONTROL_RUNNING || snapshot->measured_left < -1 ||
        snapshot->measured_left > 1 || snapshot->measured_right < -1 || snapshot->measured_right > 1 ||
        !vision.valid || vision.confidence < 0.9f || vision.error_px < -5.0f || vision.error_px > 5.0f ||
        (uint32_t)(control_now_ms() - vision.capture_time_ms) > 100u) return 0u;
    for (row = 0; row < CONTROL_IMAGE_HEIGHT; ++row)
    {
        uint16_t width = (uint16_t)(vision.right[row] - vision.left[row]);
        widths[row] = vision.row_quality[row] == 2u && width >= 3u && width < CONTROL_IMAGE_WIDTH ? width : 0u;
    }
    for (i = 0; i < CONTROL_BAND_COUNT; ++i)
        if (widths[params->look_rows[i]] == 0u) return 0u;
    for (row = 0; row < CONTROL_IMAGE_HEIGHT; ++row)
        if (!vision_set_reference_width(row, widths[row])) return 0u;
    vision_reset();
    return 1u;
}

int main(void)
{
    uint32_t band_version = 0u;
    uint32_t last_display_ms = 0u;
    uint32_t calibration_request_ms = 0u;
    uint8_t calibration_pending = 0u;
    clock_init(SYSTEM_CLOCK_600M);
    debug_init();
    system_delay_ms(300);
    Init();
    interrupt_global_enable(0);

    while (1)
    {
        ControlParams params;
        ControlSnapshot snapshot;
        uint32_t version;
        uint32_t frame_id;
        uint32_t capture_ms;
        control_get_params(&params, &version);
        if (version != band_version)
        {
            if (vision_set_control_band(params.look_rows, params.look_weights)) band_version = version;
            else control_report_invalid_fault();
        }
        if (wifi_assistant_take_width_calibration_request())
        {
            calibration_pending = 1u;
            calibration_request_ms = control_now_ms();
        }
        // 优先处理新帧，显示和网络不得抢在视觉与控制目标发布之前。
        if (camera_frame_take((uint8_t *)image, &frame_id, &capture_ms))
        {
            uint8_t threshold;
            wifi_assistant_capture_raw((const uint8 *)image);
            get_hist_gram((uint8_t *)image, MT9V03X_H, MT9V03X_W, hist_gram);
            threshold = get_threshold_otsu(hist_gram);
            binaryzation_process((uint8_t *)image, MT9V03X_H, MT9V03X_W, threshold);
            vision_process((uint8_t *)image, frame_id, capture_ms, &vision);
            vision.threshold = threshold;
            control_publish_vision(&vision);
            control_get_snapshot(&snapshot);
            if (calibration_pending)
            {
                uint8_t accepted = calibrate_width(&params, &snapshot);
                calibration_pending = 0u;
                printf("[vision] width calibration %s\r\n", accepted ? "OK" : "REJECTED");
            }
            if (snapshot.state != CONTROL_RUNNING &&
                (uint32_t)(control_now_ms() - last_display_ms) >= 200u)
            {
                last_display_ms = control_now_ms();
                tft180_displayimage03x((uint8_t *)image, 125, 100);
                tft180_show_int(0, 0, snapshot.measured_left, 3);
                tft180_show_int(0, 30, snapshot.measured_right, 3);
                tft180_show_float(0, 50, snapshot.confidence, 1, 2);
                tft180_show_int(0, 70, (int32)snapshot.fault, 2);
            }
            wifi_assistant_on_frame((const uint8 *)image, vision.left, vision.middle, vision.right,
                                    vision.error_px, snapshot.servo_cmd, threshold);
        }
        if (calibration_pending && (uint32_t)(control_now_ms() - calibration_request_ms) > 1000u)
        {
            calibration_pending = 0u;
            printf("[vision] width calibration NO NEW FRAME\r\n");
        }
        wifi_assistant_poll();
    }
}
