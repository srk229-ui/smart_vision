#include "wifi_assistant.h"
#include "zf_common_headfile.h"
#include "seekfree_assistant_interface.h"
#include "control.h"

float wifi_assistant_servo_gain = WIFI_ASSISTANT_DEFAULT_SERVO_GAIN;
volatile wifi_assistant_state_enum wifi_assistant_state = WIFI_ASSISTANT_DISABLED;
volatile uint32 wifi_assistant_send_error_count;
volatile uint32 wifi_assistant_last_unsent_bytes;
volatile uint32 wifi_assistant_reconnect_count;
volatile uint32 wifi_assistant_frame_count;
volatile uint32 wifi_assistant_parameter_reject_count;

#if WIFI_ASSISTANT_ENABLE
static volatile uint32 elapsed_time_ms;
static uint32 last_send_ms;
static uint32 last_reconnect_ms;
static uint32 send_period_ms = WIFI_ASSISTANT_DEFAULT_PERIOD_MS;
static uint8 stream_mode = WIFI_ASSISTANT_DEFAULT_STREAM;
static uint8 image_mode = WIFI_ASSISTANT_DEFAULT_IMAGE;
static uint8 raw_frame_valid;
static uint8 camera_image[MT9V03X_H][MT9V03X_W];
static uint8 camera_left[MT9V03X_H];
static uint8 camera_middle[MT9V03X_H];
static uint8 camera_right[MT9V03X_H];
static uint8 width_calibration_request;
static uint8 stop_seen;
static ControlMode selected_mode = CONTROL_MODE_TRACK;
static wifi_assistant_state_enum displayed_state = WIFI_ASSISTANT_DISABLED;

#if WIFI_SPI_AUTO_CONNECT != 0
#error "Use WIFI_SPI_AUTO_CONNECT = 0; wifi_assistant_init establishes the socket explicitly"
#endif

#if MT9V03X_W > 256
#error "The existing demo uses 8-bit boundary coordinates"
#endif

/* 行车发送只尝试一次；停止态才允许延时续传和自动恢复。 */
static uint32 assistant_send(const uint8 *buffer, uint32 length)
{
    uint8 attempt;
    uint8 running = control_get_state() == CONTROL_RUNNING || wifi_spi_service_is_running();
    uint8 attempts = running ? 1 : WIFI_ASSISTANT_SEND_ATTEMPTS;
    uint32 remaining = length;
    uint32 io_errors = wifi_spi_io_error_count;
    if(wifi_assistant_state != WIFI_ASSISTANT_READY)
    {
        return length;
    }
    for(attempt = 0; remaining != 0 && attempt < attempts; ++attempt)
    {
        remaining = wifi_spi_send_buffer(buffer + (length - remaining), remaining);
        if(remaining != 0)
        {
            ++wifi_assistant_send_error_count;
            wifi_assistant_last_unsent_bytes = remaining;
            if(!running && attempt + 1 < attempts)
            {
                system_delay_ms(20); // 仅停车时给模块缓冲区留出恢复时间
            }
        }
    }
    if(remaining != 0 || (running && wifi_spi_io_error_count != io_errors))
    {
        wifi_assistant_state = WIFI_ASSISTANT_SEND_ERROR;
        raw_frame_valid = 0;
        last_reconnect_ms = elapsed_time_ms;
        if(running)
        {
            control_report_link_fault();
        }
    }
    return remaining;
}

static void show_state(void)
{
    const char *text;
    if(displayed_state == wifi_assistant_state)
    {
        return;
    }
    displayed_state = wifi_assistant_state;
    switch(displayed_state)
    {
        case WIFI_ASSISTANT_INITIALIZING: text = "WIFI INIT...    "; break;
        case WIFI_ASSISTANT_MODULE_ERROR: text = "WIFI INIT FAIL  "; break;
        case WIFI_ASSISTANT_LINK_ERROR:   text = "WIFI LINK FAIL  "; break;
        case WIFI_ASSISTANT_READY:        text = "WIFI OK         "; break;
        case WIFI_ASSISTANT_SEND_ERROR:   text = "WIFI SEND FAIL  "; break;
        case WIFI_ASSISTANT_WIFI_ERROR:   text = "WIFI JOIN FAIL  "; break;
        default:                         text = "WIFI OFF        "; break;
    }
    tft180_show_string(0, 112, text);
    printf("[wifi_assistant] %s\r\n", text);
}

/* 每个合法线上参数包都观察一次，不能让后续同通道包覆盖停止语义。 */
static void assistant_parameter_event(uint8 channel, float value)
{
    if(channel == 1 && value == 0.0f) { stop_seen = 1; }
}

/* 同一轮先收集请求，停车参数统一提交，避免左右轮出现不同版本。 */
static void apply_parameters(uint8 initially_running)
{
    uint8 channel;
    uint8 updated[SEEKFREE_ASSISTANT_SET_PARAMETR_COUNT];
    float values[SEEKFREE_ASSISTANT_SET_PARAMETR_COUNT];
    uint8 dirty = 0;
    uint8 control_batch_valid = 1;
    uint8 start_requested = 0;
    uint8 start_cancelled = 0;
    uint32 version;
    ControlParams params;
    for(channel = 0; channel < SEEKFREE_ASSISTANT_SET_PARAMETR_COUNT; ++channel)
    {
        updated[channel] = seekfree_assistant_parameter_update_flag[channel];
        values[channel] = seekfree_assistant_parameter[channel];
        seekfree_assistant_parameter_update_flag[channel] = 0;
    }
    /* 同批只要出现过停止就立即结束，不应用其它运动参数或后续启动。 */
    if(stop_seen || (updated[0] && values[0] == 0.0f))
    {
        stop_seen = 0;
        control_request_stop();
        for(channel = 0; channel < SEEKFREE_ASSISTANT_SET_PARAMETR_COUNT; ++channel)
        {
            if(updated[channel] && !(channel == 0 && values[channel] == 0.0f))
            {
                ++wifi_assistant_parameter_reject_count;
            }
        }
        return;
    }
    if(initially_running)
    {
        for(channel = 0; channel < SEEKFREE_ASSISTANT_SET_PARAMETR_COUNT; ++channel)
        {
            if(updated[channel] && !(channel == 0 && values[channel] == 0.0f))
            {
                ++wifi_assistant_parameter_reject_count;
            }
        }
        return;
    }
    control_get_params(&params, &version);
    for(channel = 0; channel < SEEKFREE_ASSISTANT_SET_PARAMETR_COUNT; ++channel)
    {
        float value = values[channel];
        if(!updated[channel])
        {
            continue;
        }
        switch(channel)
        {
            case 0:
                if(value > 0.0f && value <= 100.0f)
                {
                    params.target_left = params.target_right = value;
                    dirty = 1;
                    start_requested = 1;
                }
                else if(value != 0.0f)
                {
                    control_batch_valid = 0;
                    ++wifi_assistant_parameter_reject_count;
                }
                break;
            case 1:
            case 2:
                if(value >= 0.0f && value <= 1000.0f)
                {
                    if(channel == 1)
                    {
                        params.kp_left = params.kp_right = value;
                    }
                    else
                    {
                        params.ki_left = params.ki_right = value;
                    }
                    dirty = 1;
                }
                else
                {
                    control_batch_valid = 0;
                    ++wifi_assistant_parameter_reject_count;
                }
                break;
            case 3:
                /* 速度微分固定为零，此通道只接收下列人工操作整数。 */
                if(value == 0.0f) { }
                else if(value == 1.0f) { selected_mode = CONTROL_MODE_TRACK; }
                else if(value == 2.0f) { selected_mode = CONTROL_MODE_BENCH; }
                else if(value == 3.0f)
                {
                    if(!control_reset_fault()) { ++wifi_assistant_parameter_reject_count; }
                }
                else if(value == 4.0f) { params.calibration_confirmed = 1; dirty = 1; }
                else if(value == 5.0f)
                {
                    control_request_stop();
                    params.calibration_confirmed = 0;
                    dirty = 1;
                    start_cancelled = 1;
                }
                else if(value == 6.0f) { width_calibration_request = 1; start_cancelled = 1; }
                else
                {
                    control_batch_valid = 0;
                    ++wifi_assistant_parameter_reject_count;
                }
                break;
            case 4:
                if(value >= 0.0f && value <= 5.0f)
                {
                    params.steer_kp = value;
                    dirty = 1;
                }
                else
                {
                    control_batch_valid = 0;
                    ++wifi_assistant_parameter_reject_count;
                }
                break;
            case 5:
                if(value == 0.0f || value == 1.0f || value == 2.0f)
                {
                    stream_mode = (uint8)value;
                    raw_frame_valid = 0;
                    last_send_ms = elapsed_time_ms;
                }
                else { ++wifi_assistant_parameter_reject_count; }
                break;
            case 6:
                if(value == 0.0f || value == 1.0f)
                {
                    image_mode = (uint8)value;
                    raw_frame_valid = 0;
                }
                else { ++wifi_assistant_parameter_reject_count; }
                break;
            case 7:
                if(value >= 20.0f && value <= 1000.0f)
                {
                    send_period_ms = (uint32)value;
                }
                else { ++wifi_assistant_parameter_reject_count; }
                break;
        }
    }
    if(!control_batch_valid)
    {
        return;
    }
    if(dirty)
    {
        if(!control_apply_params(&params, version))
        {
            ++wifi_assistant_parameter_reject_count;
            return;
        }
        wifi_assistant_servo_gain = params.steer_kp;
    }
    if(start_requested && !start_cancelled && !control_request_run(selected_mode))
    {
        ++wifi_assistant_parameter_reject_count;
    }
}
#endif

//-------------------------------------------------------------------------------------------------------------------
// 函数简介     WIFI-SPI 模块及逐飞助手 V1 接口初始化
// 参数说明     void            无
// 返回参数     void
// 备注信息     只在上电或停止态调用；连接失败时显示状态并返回
//-------------------------------------------------------------------------------------------------------------------
void wifi_assistant_init(void)
{
#if WIFI_ASSISTANT_ENABLE
    wifi_spi_service_begin(0);
    seekfree_assistant_parameter_observer = assistant_parameter_event;
    seekfree_assistant_receive_reset();
    width_calibration_request = 0;
    stop_seen = 0;
    wifi_assistant_state = WIFI_ASSISTANT_INITIALIZING;
    raw_frame_valid = 0;
    last_reconnect_ms = elapsed_time_ms;
    show_state();
    seekfree_assistant_interface_init(SEEKFREE_ASSISTANT_WIFI_SPI);
    seekfree_assistant_transfer_callback = assistant_send;
    /* V2.0 先检查模块通信，再单独连接热点，便于定位初始化失败阶段 */
    if(wifi_spi_init(NULL, NULL) || wifi_spi_version[0] == '\0')
    {
        wifi_assistant_state = WIFI_ASSISTANT_MODULE_ERROR;
        last_reconnect_ms = elapsed_time_ms;
        show_state();
        return;
    }

    printf("[wifi_assistant] firmware=%s, MAC=%s\r\n", wifi_spi_version, wifi_spi_mac_addr);
    if(wifi_spi_wifi_connect(WIFI_ASSISTANT_SSID, WIFI_ASSISTANT_PASSWORD))
    {
        wifi_assistant_state = WIFI_ASSISTANT_WIFI_ERROR;
        last_reconnect_ms = elapsed_time_ms;
        show_state();
        return;
    }

#if WIFI_ASSISTANT_TRANSPORT == 1
    if(wifi_spi_socket_connect("TCP", WIFI_ASSISTANT_TARGET_IP, WIFI_SPI_TARGET_PORT, WIFI_SPI_LOCAL_PORT))
#else
    if(wifi_spi_socket_connect("UDP", WIFI_ASSISTANT_TARGET_IP, WIFI_SPI_TARGET_PORT, WIFI_SPI_LOCAL_PORT))
#endif
    {
        wifi_assistant_state = WIFI_ASSISTANT_LINK_ERROR;
        last_reconnect_ms = elapsed_time_ms;
        show_state();
        return;
    }

    seekfree_assistant_camera_information_config(SEEKFREE_ASSISTANT_MT9V03X,
                                                  camera_image[0], MT9V03X_W, MT9V03X_H);
    seekfree_assistant_camera_boundary_config(SEEKFREE_ASSISTANT_X_BOUNDARY, MT9V03X_H,
                                               camera_left, camera_middle, camera_right,
                                               NULL, NULL, NULL);
    last_send_ms = elapsed_time_ms; // 重连后发送最新完整帧，避免续接旧连接的半帧
    wifi_assistant_state = WIFI_ASSISTANT_READY;
    printf("[wifi_assistant] module=%s, PC=%s:%s\r\n",
           wifi_spi_ip_addr_port, WIFI_ASSISTANT_TARGET_IP, WIFI_SPI_TARGET_PORT);
    show_state();
#endif
}

//-------------------------------------------------------------------------------------------------------------------
// 函数简介     更新上位机通信计时
// 参数说明     elapsed_ms      本次经过的时间，单位 ms
// 返回参数     void
// 备注信息     由现有控制定时器调用，不在中断中执行网络收发
//-------------------------------------------------------------------------------------------------------------------
void wifi_assistant_tick(uint32 elapsed_ms)
{
#if WIFI_ASSISTANT_ENABLE
    elapsed_time_ms += elapsed_ms;
#else
    (void)elapsed_ms;
#endif
}

//-------------------------------------------------------------------------------------------------------------------
// 函数简介     处理逐飞助手参数及示波器数据
// 参数说明     void            无
// 返回参数     void
// 备注信息     主循环调用；行车固定十次每秒波形，停车后通道五选择图像或波形
//-------------------------------------------------------------------------------------------------------------------
void wifi_assistant_poll(void)
{
#if WIFI_ASSISTANT_ENABLE
    uint32 now;
    uint32 io_errors;
    uint32 parser_errors;
    uint8 initially_running = control_get_state() == CONTROL_RUNNING;
    ControlSnapshot snapshot;
    seekfree_assistant_oscilloscope_struct wave;
    wifi_spi_service_begin(initially_running);
    if(!initially_running) { show_state(); }
    if(wifi_assistant_state != WIFI_ASSISTANT_READY)
    {
        if(initially_running)
        {
            control_report_link_fault();
        }
        else if((wifi_assistant_state == WIFI_ASSISTANT_MODULE_ERROR ||
                 wifi_assistant_state == WIFI_ASSISTANT_WIFI_ERROR ||
                 wifi_assistant_state == WIFI_ASSISTANT_LINK_ERROR ||
                 wifi_assistant_state == WIFI_ASSISTANT_SEND_ERROR) &&
                (uint32)(elapsed_time_ms - last_reconnect_ms) >= WIFI_ASSISTANT_RECONNECT_PERIOD_MS)
        {
            ++wifi_assistant_reconnect_count;
            /* 行车期间绝不进入复位、热点连接和网络重连。 */
            wifi_assistant_init();
        }
        wifi_spi_service_end();
        return;
    }
    io_errors = wifi_spi_io_error_count;
    parser_errors = seekfree_assistant_receive_error_count;
    seekfree_assistant_data_analysis();
    if(wifi_spi_io_error_count != io_errors || seekfree_assistant_receive_error_count != parser_errors)
    {
        wifi_assistant_state = WIFI_ASSISTANT_SEND_ERROR;
        raw_frame_valid = 0;
        last_reconnect_ms = elapsed_time_ms;
        /* 错误轮次同时清除半包和更新旗标，避免重连后复用陈旧启动命令。 */
        seekfree_assistant_receive_reset();
        width_calibration_request = 0;
        stop_seen = 0;
        if(initially_running) { control_report_link_fault(); }
        wifi_spi_service_end();
        return;
    }
    apply_parameters(initially_running);
    control_get_snapshot(&snapshot);
    if(initially_running && snapshot.state != CONTROL_RUNNING)
    {
        /* 停止发生的行车轮次立即结束；下一轮停车通信才允许恢复方式。 */
        wifi_spi_service_end();
        return;
    }
    /* 停车接收后刚启动的本轮，也必须启用行车通信总预算。 */
    if(!initially_running && snapshot.state == CONTROL_RUNNING)
    {
        wifi_spi_service_begin(1);
    }
    now = elapsed_time_ms;
    if(wifi_assistant_state != WIFI_ASSISTANT_READY ||
       (snapshot.state != CONTROL_RUNNING && stream_mode != 2) ||
       (uint32)(now - last_send_ms) < (snapshot.state == CONTROL_RUNNING ? WIFI_ASSISTANT_RUNNING_PERIOD_MS : send_period_ms))
    {
        wifi_spi_service_end();
        return;
    }
    last_send_ms = now;
    wave.channel_num = 8;
    wave.data[0] = snapshot.target_left;
    wave.data[1] = snapshot.target_right;
    wave.data[2] = (float)snapshot.measured_left;
    wave.data[3] = (float)snapshot.measured_right;
    wave.data[4] = snapshot.pwm_left;
    wave.data[5] = snapshot.pwm_right;
    wave.data[6] = snapshot.vision_error_px;
    wave.data[7] = snapshot.servo_cmd;
    seekfree_assistant_oscilloscope_send(&wave);
    wifi_spi_service_end();
#endif
}

//-------------------------------------------------------------------------------------------------------------------
// 函数简介     保存待发送的原始灰度图像
// 参数说明     *image          当前摄像头图像首地址
// 返回参数     void
// 备注信息     必须在原地二值化之前调用，只在原始图传到期时复制
//-------------------------------------------------------------------------------------------------------------------
void wifi_assistant_capture_raw(const uint8 *image)
{
#if WIFI_ASSISTANT_ENABLE
    raw_frame_valid = 0;
    if(control_get_state() != CONTROL_RUNNING && wifi_assistant_state == WIFI_ASSISTANT_READY && stream_mode == 1 && image_mode == 0 &&
       (uint32)(elapsed_time_ms - last_send_ms) >= send_period_ms)
    {
        memcpy(camera_image, image, sizeof(camera_image));
        raw_frame_valid = 1;
    }
#else
    (void)image;
#endif
}

//-------------------------------------------------------------------------------------------------------------------
// 函数简介     发送当前图像、边线并更新图像调试数据
// 参数说明     *image          处理后图像首地址
// 参数说明     *left / *middle / *right左边线、中线和右边线数组
// 参数说明     mid_error       当前中线偏差
// 参数说明     servo_angle     当前舵机控制角度
// 参数说明     threshold       当前二值化阈值
// 返回参数     void
// 备注信息     主循环完成图像处理后调用；按设定周期发送，避免每帧都占用链路
//-------------------------------------------------------------------------------------------------------------------
void wifi_assistant_on_frame(const uint8 *image, const uint8 *left,
                             const uint8 *middle, const uint8 *right,
                             float mid_error, float servo_angle, uint8 threshold)
{
#if WIFI_ASSISTANT_ENABLE
    uint32 now = elapsed_time_ms;
    (void)mid_error;
    (void)servo_angle;
    (void)threshold;
    if(control_get_state() == CONTROL_RUNNING || wifi_assistant_state != WIFI_ASSISTANT_READY || stream_mode != 1 ||
       (uint32)(now - last_send_ms) < send_period_ms)
    {
        return;
    }
    if(image_mode == 0)
    {
        if(!raw_frame_valid)
        {
            return;
        }
        raw_frame_valid = 0;
    }
    else
    {
        memcpy(camera_image, image, sizeof(camera_image));
    }
    memcpy(camera_left, left, sizeof(camera_left));
    memcpy(camera_middle, middle, sizeof(camera_middle));
    memcpy(camera_right, right, sizeof(camera_right));
    last_send_ms = now;
    wifi_spi_service_begin(0);
    seekfree_assistant_camera_send();
    wifi_spi_service_end();
    if(wifi_assistant_state == WIFI_ASSISTANT_READY)
    {
        ++wifi_assistant_frame_count; // 仅统计图像及边线全部发送成功的完整帧
    }
#else
    (void)image;
    (void)left;
    (void)middle;
    (void)right;
    (void)mid_error;
    (void)servo_angle;
    (void)threshold;
#endif
}

//-------------------------------------------------------------------------------------------------------------------
// 函数简介     取出一次静止直道宽度标定请求
// 参数说明     void            无
// 返回参数     uint8           1-有新请求，0-没有新请求
// 备注信息     主循环消费请求，实际标定与有效性检查由视觉模块完成
//-------------------------------------------------------------------------------------------------------------------
uint8 wifi_assistant_take_width_calibration_request(void)
{
#if WIFI_ASSISTANT_ENABLE
    uint8 requested = width_calibration_request;
    width_calibration_request = 0;
    return requested;
#else
    return 0;
#endif
}
