#ifndef WIFI_ASSISTANT_CONFIG_H
#define WIFI_ASSISTANT_CONFIG_H

/* WIFI-SPI 通信开关及热点信息；电脑端 2.4 GHz 热点设置为相同名称和密码 */
#define WIFI_ASSISTANT_ENABLE             (1)
#define WIFI_ASSISTANT_SSID               "SEEKFREE"
#define WIFI_ASSISTANT_PASSWORD           "SEEKFREE123"

/* 电脑与模块接入同一热点；目标 IP 为电脑当前 WLAN 的 IPv4 地址 */
#define WIFI_ASSISTANT_TARGET_IP          "10.138.155.234"

/* 通信协议：1-电脑作为 TCP Server  2-UDP；端口在 zf_device_wifi_spi.h 中设置 */
#define WIFI_ASSISTANT_TRANSPORT          (1)

/* 助手界面通道5：0-仅接收参数  1-图像传输  2-虚拟示波器 */
#define WIFI_ASSISTANT_DEFAULT_STREAM     (1)
/* 助手界面通道6：0-原始灰度图像  1-处理后的图像（仍以8位灰度格式传输） */
#define WIFI_ASSISTANT_DEFAULT_IMAGE      (0)
/* 助手界面通道7：发送周期，单位 ms；100 ms 对应最高约10帧/秒 */
#define WIFI_ASSISTANT_DEFAULT_PERIOD_MS  (100)
#define WIFI_ASSISTANT_DEFAULT_SERVO_GAIN (0.5f)
/* 行车固定为最高十次每秒波形；不发送图像，不由此周期改变控制采样。 */
#define WIFI_ASSISTANT_RUNNING_PERIOD_MS  (100)

/* 停止态每块数据最多尝试次数；只有停止后才允许重建模块及网络连接。 */
#define WIFI_ASSISTANT_SEND_ATTEMPTS      (3)
#define WIFI_ASSISTANT_RECONNECT_PERIOD_MS (2000)

#if WIFI_ASSISTANT_SEND_ATTEMPTS < 1 || WIFI_ASSISTANT_SEND_ATTEMPTS > 5
#error "WIFI_ASSISTANT_SEND_ATTEMPTS must be between 1 and 5"
#endif

#if WIFI_ASSISTANT_RECONNECT_PERIOD_MS < 1000 || WIFI_ASSISTANT_RECONNECT_PERIOD_MS > 60000
#error "WIFI_ASSISTANT_RECONNECT_PERIOD_MS must be between 1000 and 60000"
#endif

#if WIFI_ASSISTANT_TRANSPORT != 1 && WIFI_ASSISTANT_TRANSPORT != 2
#error "WIFI_ASSISTANT_TRANSPORT must be 1 (TCP) or 2 (UDP)"
#endif

#if WIFI_ASSISTANT_DEFAULT_STREAM < 0 || WIFI_ASSISTANT_DEFAULT_STREAM > 2
#error "WIFI_ASSISTANT_DEFAULT_STREAM must be 0, 1 or 2"
#endif

#if WIFI_ASSISTANT_DEFAULT_IMAGE != 0 && WIFI_ASSISTANT_DEFAULT_IMAGE != 1
#error "WIFI_ASSISTANT_DEFAULT_IMAGE must be 0 or 1"
#endif

#if WIFI_ASSISTANT_DEFAULT_PERIOD_MS < 20 || WIFI_ASSISTANT_DEFAULT_PERIOD_MS > 1000
#error "WIFI_ASSISTANT_DEFAULT_PERIOD_MS must be between 20 and 1000"
#endif

#endif
