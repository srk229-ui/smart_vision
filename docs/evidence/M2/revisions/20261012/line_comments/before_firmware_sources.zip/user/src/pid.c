#include "pid.h"
#include <math.h>

// 电机PID初始化参数
float speed_KP = 50, speed_KI = 0,speed_KD = 0.0, speed_IMAX = 5000.0, speed_OUTMAX = 5000.0;
float speed_target = 0.0;
float speed_real = 0.0;
float speed_pwm = 0.0;

pid_param_t speed_pid_l;  // 电机PID
pid_param_t speed_pid_r;  // 电机PID

/*******************************************************************************
* 函 数 名         : My_Pid_Init
* 函数功能         : PID初始化	
* 输    入         : 无
* 输    出         : 无
*******************************************************************************/
void My_Pid_Init(void)
{
    Pid_Param_Init(&speed_pid_l, speed_KP, speed_KI,speed_KD, speed_IMAX, speed_OUTMAX);
    Pid_Param_Init(&speed_pid_r, speed_KP, speed_KI,speed_KD, speed_IMAX, speed_OUTMAX);
}


/*******************************************************************************
* 函 数 名         : Pid_Param_Init
* 函数功能         : PID参数初始化	
* 输    入         : imax:积分项最大值
* 输    出         : 无
*******************************************************************************/
void Pid_Param_Init(pid_param_t * pid, float kp, float ki, float kd, float imax, float outmax)
{
    if (pid == NULL)
    {
        return;
    }
    pid->kp        = kp;
    pid->ki        = ki;
    pid->kd        = kd;
    pid->imax      = imax;
    pid->outmax    = outmax;
    Pid_Reset(pid);
}

//-------------------------------------------------------------------------------------------------------------------
// 函数简介     清空控制历史，保留增益和限幅配置
// 参数说明     pid             控制器指针，空指针时直接返回
// 返回参数     void
// 备注信息     由控制层在停机、故障和控制模式切换时同步调用
//-------------------------------------------------------------------------------------------------------------------
void Pid_Reset(pid_param_t *pid)
{
    if (pid == NULL)
    {
        return;
    }
    pid->out_p = 0.0f;
    pid->out_i = 0.0f;
    pid->out_d = 0.0f;
    pid->out = 0.0f;
    pid->out_raw = 0.0f;
    pid->integrator = 0.0f;
    pid->last_error = 0.0f;
    pid->last_derivative = 0.0f;
    pid->last_t = 0;
}

// 检查输入、配置及会参与本次计算的历史状态，防止非法数值进入 PWM 输出。
static int pid_input_valid(const pid_param_t *pid, float error, float dt_s)
{
    return pid != NULL && isfinite(error) && isfinite(dt_s) && dt_s > 0.0f &&
           isfinite(pid->kp) && pid->kp >= 0.0f &&
           isfinite(pid->ki) && pid->ki >= 0.0f &&
           isfinite(pid->kd) && pid->kd >= 0.0f &&
           isfinite(pid->imax) && pid->imax >= 0.0f &&
           isfinite(pid->outmax) && pid->outmax >= 0.0f &&
           isfinite(pid->integrator) && isfinite(pid->last_error) &&
           isfinite(pid->last_derivative) && isfinite(pid->out);
}

// 已饱和时只允许积分向解除饱和的方向变化。
static int pid_integral_allowed(float raw_output, float error, float outmax)
{
    return !((raw_output > outmax && error > 0.0f) ||
             (raw_output < 0.0f && error < 0.0f));
}

/*******************************************************************************
* 函 数 名         : PidLocCtrl
* 函数功能	   : 位置式PID控制
* 输    入         : pid, error, dt_s（单位为秒）
* 输    出         : float
*******************************************************************************/
float PidLocCtrl(pid_param_t *pid, float error, float dt_s)
{
    float integral_delta;
    float integral_candidate;
    float raw_candidate;

    if (!pid_input_valid(pid, error, dt_s))
    {
        Pid_Reset(pid);
        return 0.0f;
    }

    // 积分直接保存输出贡献，关闭 Ki 后不留下可在重新启用时释放的误差历史。
    pid->integrator = pid->ki == 0.0f ? 0.0f :
                      constrain_float(pid->integrator, -pid->imax, pid->imax);
    pid->out_p = pid->kp * error;
    pid->out_d = pid->kd == 0.0f ? 0.0f :
                 pid->kd * ((error - pid->last_error) / dt_s);
    integral_delta = pid->ki == 0.0f ? 0.0f : pid->ki * dt_s * error;
    if (!isfinite(pid->out_p) || !isfinite(pid->out_d) || !isfinite(integral_delta) ||
        !isfinite(pid->integrator + integral_delta))
    {
        Pid_Reset(pid);
        return 0.0f;
    }

    integral_candidate = constrain_float(pid->integrator + integral_delta, -pid->imax, pid->imax);
    raw_candidate = pid->out_p + integral_candidate + pid->out_d;
    if (!isfinite(raw_candidate))
    {
        Pid_Reset(pid);
        return 0.0f;
    }
    if (pid_integral_allowed(raw_candidate, error, pid->outmax))
    {
        pid->integrator = integral_candidate;
    }
    else
    {
        float integral_at_limit = (raw_candidate > pid->outmax ? pid->outmax : 0.0f) -
                                  pid->out_p - pid->out_d;
        if (!isfinite(integral_at_limit))
        {
            Pid_Reset(pid);
            return 0.0f;
        }
        // 尚未到达输出边界时只积分到边界，避免整步拒绝造成限位前残留。
        if ((error > 0.0f && integral_at_limit > pid->integrator) ||
            (error < 0.0f && integral_at_limit < pid->integrator))
        {
            pid->integrator = constrain_float(integral_at_limit, -pid->imax, pid->imax);
        }
    }

    pid->out_i = pid->integrator;
    pid->out_raw = pid->out_p + pid->out_i + pid->out_d;
    if (!isfinite(pid->out_raw))
    {
        Pid_Reset(pid);
        return 0.0f;
    }
    pid->out = constrain_float(pid->out_raw, 0.0f, pid->outmax);
    pid->last_error = error;
    return pid->out;
}


/*******************************************************************************
* 函 数 名         : PidIncCtrl
* 函数功能	   : 增量式PID控制
* 输    入         : pid, error, dt_s（单位为秒）
* 输    出         : float
* 备注信息         : 仅保留兼容，主速度环使用 PidLocCtrl；切换前清空历史
*******************************************************************************/
float PidIncCtrl(pid_param_t *pid, float error, float dt_s)
{
    float error_delta;
    float raw_candidate;

    if (!pid_input_valid(pid, error, dt_s))
    {
        Pid_Reset(pid);
        return 0.0f;
    }
    error_delta = error - pid->last_error;
    pid->out_p = pid->kp * error_delta;
    pid->out_i = pid->ki == 0.0f ? 0.0f : pid->ki * dt_s * error;
    pid->out_d = pid->kd == 0.0f ? 0.0f :
                 pid->kd * ((error_delta - pid->last_derivative) / dt_s);
    if (!isfinite(error_delta) || !isfinite(pid->out_p) ||
        !isfinite(pid->out_i) || !isfinite(pid->out_d))
    {
        Pid_Reset(pid);
        return 0.0f;
    }
    pid->out_i = constrain_float(pid->out_i, -pid->imax, pid->imax);
    raw_candidate = pid->out + pid->out_p + pid->out_i + pid->out_d;
    if (!isfinite(raw_candidate))
    {
        Pid_Reset(pid);
        return 0.0f;
    }
    if (!pid_integral_allowed(raw_candidate, error, pid->outmax))
    {
        pid->out_i = 0.0f;
    }

    pid->out_raw = pid->out + pid->out_p + pid->out_i + pid->out_d;
    if (!isfinite(pid->out_raw))
    {
        Pid_Reset(pid);
        return 0.0f;
    }
    pid->out = constrain_float(pid->out_raw, 0.0f, pid->outmax);
    pid->integrator = 0.0f;
    pid->last_derivative = error_delta;
    pid->last_error = error;
    return pid->out;
}

/*******************************************************************************
* 函 数 名         : constrain_float
* 函数功能         : 浮点型数限幅
* 输    入         : amt,low,high
* 输    出         : float
*******************************************************************************/
float constrain_float(float amt, float low, float high)
{
    return ((amt)<(low)?(low):((amt)>(high)?(high):(amt)));
}

/*******************************************************************************
* 函 数 名         : constrain_short
* 函数功能         : 短整型数限幅
* 输    入         : amt,low,high
* 输    出         : short
*******************************************************************************/
short constrain_short(short amt, short low, short high)
{
    return ((amt)<(low)?(low):((amt)>(high)?(high):(amt)));
}

