#ifndef _IMG_PROCESS_H_
#define _IMG_PROCESS_H_

#include <stdint.h>
#include "control_types.h"

// 函数简介     获取完整清零的三十二位灰度直方图
// 参数说明     图像、行列尺寸及 256 个 uint32_t 计数空间
// 返回参数     void
void get_hist_gram(unsigned char *_img, unsigned short _rows, unsigned short _cols,
                   uint32_t *_hist_gram);
// 函数简介     计算 Otsu 阈值，处理空直方图和纯色输入
// 参数说明     已统计的 256 个灰度计数
// 返回参数     unsigned char 阈值
unsigned char get_threshold_otsu(const uint32_t *_hist_gram);
// 函数简介     把灰度图原地转换为零或二百五十五
// 参数说明     图像、行列尺寸及灰度阈值
// 返回参数     void
void binaryzation_process(unsigned char *_img, unsigned short _rows, unsigned short _cols,
                          unsigned int _threshold_value);
// 函数简介     保留兼容的逐行扫描入口，新控制链使用 vision_process
// 参数说明     二值图、尺寸及边线输出；灰度阈值不再参与判黑
// 返回参数     void
void auxiliary_process(uint8_t *_src_pixel_mat, uint8_t _src_rows, uint8_t _src_cols,
                        unsigned char _threshold_val, uint8_t *_left_line,
                        uint8_t *_mid_line, uint8_t *_right_line);

// 函数简介：清除跨帧种子、重建计数和帧缓存，保留人工标定及控制带配置。
// 参数说明：无。
// 返回参数：无。
// 备注信息：新试验前调用，默认参考宽度为零，不能自动假定标定成功。
void vision_reset(void);

// 函数简介：处理固定 188×120 二值图，生成边界、置信度和加权偏差。
// 参数说明：图像为连续 0/255 像素；帧编号单调递增；时间为真实采集时间。
// 返回参数：有效为 1，否则为 0；结果中的 track_lost 同时标明失效。
// 备注信息：不修改输入；调用后填写 result->threshold；无效行中点仅供显示。
uint8_t vision_process(const uint8_t *binary_after_otsu, uint32_t frame_id,
                       uint32_t capture_time_ms, VisionResult *result);

// 函数简介：设置人工居中直道标定宽度，宽度为左右白段边界之差。
// 参数说明：行号 0～119；宽度 3～187；宽度为零清除该行标定。
// 返回参数：接受为 1，非法参数为 0。
// 备注信息：仅停止态修改；重建边界可在画面外，显示坐标会限幅。
uint8_t vision_set_reference_width(uint16_t row, uint16_t width);

// 函数简介：完整验证后一次性设置五行前瞻控制带及权重。
// 参数说明：行号严格递增且小于 120；权重必须为有限正数。
// 返回参数：接受为 1，非法参数为 0 且保留原配置。
// 备注信息：仅停止态修改；默认行 80/85/90/95/100，权重 1/2/4/2/1。
uint8_t vision_set_control_band(const uint8_t rows[CONTROL_BAND_COUNT],
                                const float weights[CONTROL_BAND_COUNT]);

#endif
