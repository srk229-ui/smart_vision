#include "zf_common_headfile.h"
#include "control.h"
#include "camera_frame.h"

static csi_transfer_callback_t original_callback;
static void *original_user_data;
static volatile uint32_t frame_sequence;
static volatile uint32_t captured_ms;
static uint8_t * volatile completed_image;
static uint32_t consumed_sequence;
static uint32_t dropped_frames;

static void frame_callback(CSI_Type *base, csi_handle_t *handle, status_t status, void *user_data)
{
    (void)user_data;
    if (status == kStatus_CSI_FrameDone) mt9v03x_finish_flag = 0u;
    if (original_callback != NULL) original_callback(base, handle, status, original_user_data);
    if (status == kStatus_CSI_FrameDone && mt9v03x_finish_flag)
    {
        completed_image = (uint8_t *)mt9v03x_image;
        captured_ms = control_now_ms();
        ++frame_sequence;
    }
}

//-------------------------------------------------------------------------------------------------------------------
// 函数简介     相机初始化后包装原 CSI 回调，保持逐飞双缓冲处理
// 参数说明     void
// 返回参数     void
// 备注信息     只在应用层安装，不修改共享驱动；不得重复包装同一回调
//-------------------------------------------------------------------------------------------------------------------
void camera_frame_install(void)
{
    uint32_t key = interrupt_global_disable();
    if (csi_handle.callback != frame_callback)
    {
        original_callback = csi_handle.callback;
        original_user_data = csi_handle.userData;
        frame_sequence = consumed_sequence = dropped_frames = 0u;
        completed_image = NULL;
        csi_handle.callback = frame_callback;
    }
    interrupt_global_enable(key);
}

//-------------------------------------------------------------------------------------------------------------------
// 函数简介     领取并复制新帧，复制期间采集发生变化时丢弃该快照
// 参数说明     destination     至少容纳 188×120 字节的图像空间
// 参数说明     frame_id/capture_time_ms    对应采集完成事件的元数据
// 返回参数     uint8_t         成功为 1，没有新帧或快照失效为 0
// 备注信息     不在关闭中断期间复制整帧；结束后不清新事件标志
//-------------------------------------------------------------------------------------------------------------------
uint8_t camera_frame_take(uint8_t *destination, uint32_t *frame_id, uint32_t *capture_time_ms)
{
    uint8_t *source;
    uint32_t sequence;
    uint32_t timestamp;
    uint32_t key;
    if (destination == NULL || frame_id == NULL || capture_time_ms == NULL) return 0u;
    key = interrupt_global_disable();
    sequence = frame_sequence;
    timestamp = captured_ms;
    source = completed_image;
    if (source == NULL || sequence == consumed_sequence)
    {
        interrupt_global_enable(key);
        return 0u;
    }
    mt9v03x_finish_flag = 0u;
    interrupt_global_enable(key);
    memcpy(destination, source, CONTROL_IMAGE_WIDTH * CONTROL_IMAGE_HEIGHT);
    key = interrupt_global_disable();
    if (sequence != frame_sequence)
    {
        dropped_frames += sequence - consumed_sequence;
        consumed_sequence = sequence;
        interrupt_global_enable(key);
        return 0u;
    }
    if ((uint32_t)(sequence - consumed_sequence) > 1u)
        dropped_frames += sequence - consumed_sequence - 1u;
    consumed_sequence = sequence;
    *frame_id = sequence;
    *capture_time_ms = timestamp;
    interrupt_global_enable(key);
    return 1u;
}

uint32_t camera_frame_dropped(void)
{
    return dropped_frames;
}
