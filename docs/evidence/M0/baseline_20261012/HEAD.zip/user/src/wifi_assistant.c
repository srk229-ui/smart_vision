#include "wifi_assistant.h"
#include "zf_common_headfile.h"
#include "seekfree_assistant_interface.h"

float wifi_assistant_servo_gain = WIFI_ASSISTANT_DEFAULT_SERVO_GAIN;
volatile wifi_assistant_state_enum wifi_assistant_state = WIFI_ASSISTANT_DISABLED;
volatile uint32 wifi_assistant_send_error_count;
volatile uint32 wifi_assistant_last_unsent_bytes;
volatile uint32 wifi_assistant_reconnect_count;
volatile uint32 wifi_assistant_frame_count;

#if WIFI_ASSISTANT_ENABLE
static volatile uint32 elapsed_time_ms;
static uint32 last_send_ms;
static uint32 last_reconnect_ms;
static uint32 send_period_ms = WIFI_ASSISTANT_DEFAULT_PERIOD_MS;
static uint8 stream_mode = WIFI_ASSISTANT_DEFAULT_STREAM;
static uint8 image_mode = WIFI_ASSISTANT_DEFAULT_IMAGE;
static uint8 raw_frame_valid;
static uint8 camera_image[MT9V03X_H][MT9V03X_W];
static uint8 camera_left[MT9V03X_H];
static uint8 camera_middle[MT9V03X_H];
static uint8 camera_right[MT9V03X_H];
static float last_mid_error;
static float last_servo_angle;
static uint8 last_threshold;
static wifi_assistant_state_enum displayed_state = WIFI_ASSISTANT_DISABLED;

#if WIFI_SPI_AUTO_CONNECT != 0
#error "Use WIFI_SPI_AUTO_CONNECT = 0; wifi_assistant_init establishes the socket explicitly"
#endif

#if MT9V03X_W > 256
#error "The existing demo uses 8-bit boundary coordinates"
#endif

/* 暂时发送失败时续传未发送部分；重试耗尽后停止当前帧并等待重连 */
static uint32 assistant_send(const uint8 *buffer, uint32 length)
{
    uint8 attempt;
    uint32 remaining = length;
    if(wifi_assistant_state != WIFI_ASSISTANT_READY)
    {
        return length;
    }
    for(attempt = 0; remaining != 0 && attempt < WIFI_ASSISTANT_SEND_ATTEMPTS; ++attempt)
    {
        remaining = wifi_spi_send_buffer(buffer + (length - remaining), remaining);
        if(remaining != 0)
        {
            ++wifi_assistant_send_error_count;
            wifi_assistant_last_unsent_bytes = remaining;
            if(attempt + 1 < WIFI_ASSISTANT_SEND_ATTEMPTS)
            {
                system_delay_ms(20); // 给模块缓冲区及网络发送留出恢复时间
            }
        }
    }
    if(remaining != 0)
    {
        wifi_assistant_state = WIFI_ASSISTANT_SEND_ERROR;
        raw_frame_valid = 0;
        last_reconnect_ms = elapsed_time_ms;
    }
    return remaining;
}

static void show_state(void)
{
    const char *text;
    if(displayed_state == wifi_assistant_state)
    {
        return;
    }
    displayed_state = wifi_assistant_state;
    switch(displayed_state)
    {
        case WIFI_ASSISTANT_INITIALIZING: text = "WIFI INIT...    "; break;
        case WIFI_ASSISTANT_MODULE_ERROR: text = "WIFI INIT FAIL  "; break;
        case WIFI_ASSISTANT_LINK_ERROR:   text = "WIFI LINK FAIL  "; break;
        case WIFI_ASSISTANT_READY:        text = "WIFI OK         "; break;
        case WIFI_ASSISTANT_SEND_ERROR:   text = "WIFI SEND FAIL  "; break;
        case WIFI_ASSISTANT_WIFI_ERROR:   text = "WIFI JOIN FAIL  "; break;
        default:                         text = "WIFI OFF        "; break;
    }
    tft180_show_string(0, 112, text);
    printf("[wifi_assistant] %s\r\n", text);
}

/* 参数范围判断同时排除非数值、无穷值和越界值 */
static void apply_parameters(void)
{
    uint8 channel;
    float value;
    uint32 primask;
    for(channel = 0; channel < SEEKFREE_ASSISTANT_SET_PARAMETR_COUNT; ++channel)
    {
        if(!seekfree_assistant_parameter_update_flag[channel])
        {
            continue;
        }
        seekfree_assistant_parameter_update_flag[channel] = 0;
        value = seekfree_assistant_parameter[channel];
        switch(channel)
        {
            case 0:
                if(value >= 0.0f && value <= 100.0f)
                {
                    speed_target = value;
                }
                break;
            case 1:
            case 2:
            case 3:
                if(value >= 0.0f && value <= 1000.0f)
                {
                    /* 在短临界区中同步更新左右轮参数，保留 PID 历史状态 */
                    primask = interrupt_global_disable();
                    if(channel == 1)
                    {
                        speed_KP = speed_pid_l.kp = speed_pid_r.kp = value;
                    }
                    else if(channel == 2)
                    {
                        speed_KI = speed_pid_l.ki = speed_pid_r.ki = value;
                    }
                    else
                    {
                        speed_KD = speed_pid_l.kd = speed_pid_r.kd = value;
                    }
                    interrupt_global_enable(primask);
                }
                break;
            case 4:
                if(value >= 0.0f && value <= 5.0f)
                {
                    wifi_assistant_servo_gain = value;
                }
                break;
            case 5:
                if(value == 0.0f || value == 1.0f || value == 2.0f)
                {
                    stream_mode = (uint8)value;
                    raw_frame_valid = 0;
                    last_send_ms = elapsed_time_ms;
                }
                break;
            case 6:
                if(value == 0.0f || value == 1.0f)
                {
                    image_mode = (uint8)value;
                    raw_frame_valid = 0;
                }
                break;
            case 7:
                if(value >= 20.0f && value <= 1000.0f)
                {
                    send_period_ms = (uint32)value;
                }
                break;
        }
    }
}
#endif

//-------------------------------------------------------------------------------------------------------------------
// 函数简介     WIFI-SPI 模块及逐飞助手 V1 接口初始化
// 参数说明     void            无
// 返回参数     void
// 备注信息     在电机控制定时器启动前调用；连接失败时显示状态并返回
//-------------------------------------------------------------------------------------------------------------------
void wifi_assistant_init(void)
{
#if WIFI_ASSISTANT_ENABLE
    wifi_assistant_state = WIFI_ASSISTANT_INITIALIZING;
    raw_frame_valid = 0;
    last_reconnect_ms = elapsed_time_ms;
    show_state();
    seekfree_assistant_interface_init(SEEKFREE_ASSISTANT_WIFI_SPI);
    seekfree_assistant_transfer_callback = assistant_send;
    /* V2.0 先检查模块通信，再单独连接热点，便于定位初始化失败阶段 */
    if(wifi_spi_init(NULL, NULL) || wifi_spi_version[0] == '\0')
    {
        wifi_assistant_state = WIFI_ASSISTANT_MODULE_ERROR;
        last_reconnect_ms = elapsed_time_ms;
        show_state();
        return;
    }

    printf("[wifi_assistant] firmware=%s, MAC=%s\r\n", wifi_spi_version, wifi_spi_mac_addr);
    if(wifi_spi_wifi_connect(WIFI_ASSISTANT_SSID, WIFI_ASSISTANT_PASSWORD))
    {
        wifi_assistant_state = WIFI_ASSISTANT_WIFI_ERROR;
        last_reconnect_ms = elapsed_time_ms;
        show_state();
        return;
    }

#if WIFI_ASSISTANT_TRANSPORT == 1
    if(wifi_spi_socket_connect("TCP", WIFI_ASSISTANT_TARGET_IP, WIFI_SPI_TARGET_PORT, WIFI_SPI_LOCAL_PORT))
#else
    if(wifi_spi_socket_connect("UDP", WIFI_ASSISTANT_TARGET_IP, WIFI_SPI_TARGET_PORT, WIFI_SPI_LOCAL_PORT))
#endif
    {
        wifi_assistant_state = WIFI_ASSISTANT_LINK_ERROR;
        last_reconnect_ms = elapsed_time_ms;
        show_state();
        return;
    }

    seekfree_assistant_camera_information_config(SEEKFREE_ASSISTANT_MT9V03X,
                                                  camera_image[0], MT9V03X_W, MT9V03X_H);
    seekfree_assistant_camera_boundary_config(SEEKFREE_ASSISTANT_X_BOUNDARY, MT9V03X_H,
                                               camera_left, camera_middle, camera_right,
                                               NULL, NULL, NULL);
    last_send_ms = elapsed_time_ms; // 重连后发送最新完整帧，避免续接旧连接的半帧
    wifi_assistant_state = WIFI_ASSISTANT_READY;
    printf("[wifi_assistant] module=%s, PC=%s:%s\r\n",
           wifi_spi_ip_addr_port, WIFI_ASSISTANT_TARGET_IP, WIFI_SPI_TARGET_PORT);
    show_state();
#endif
}

//-------------------------------------------------------------------------------------------------------------------
// 函数简介     更新上位机通信计时
// 参数说明     elapsed_ms      本次经过的时间，单位 ms
// 返回参数     void
// 备注信息     由现有控制定时器调用，不在中断中执行网络收发
//-------------------------------------------------------------------------------------------------------------------
void wifi_assistant_tick(uint32 elapsed_ms)
{
#if WIFI_ASSISTANT_ENABLE
    elapsed_time_ms += elapsed_ms;
#else
    (void)elapsed_ms;
#endif
}

//-------------------------------------------------------------------------------------------------------------------
// 函数简介     处理逐飞助手参数及示波器数据
// 参数说明     void            无
// 返回参数     void
// 备注信息     在主循环中调用；图像与波形通过助手界面调参通道5选择
//-------------------------------------------------------------------------------------------------------------------
void wifi_assistant_poll(void)
{
#if WIFI_ASSISTANT_ENABLE
    uint32 now;
    uint32 primask;
    seekfree_assistant_oscilloscope_struct wave;
    show_state();
    if(wifi_assistant_state != WIFI_ASSISTANT_READY)
    {
        if((wifi_assistant_state == WIFI_ASSISTANT_MODULE_ERROR ||
            wifi_assistant_state == WIFI_ASSISTANT_WIFI_ERROR ||
            wifi_assistant_state == WIFI_ASSISTANT_LINK_ERROR ||
            wifi_assistant_state == WIFI_ASSISTANT_SEND_ERROR) &&
           (uint32)(elapsed_time_ms - last_reconnect_ms) >= WIFI_ASSISTANT_RECONNECT_PERIOD_MS)
        {
            ++wifi_assistant_reconnect_count;
            /* 复位模块并重新建立连接，丢弃失败帧，恢复后从新帧头开始 */
            wifi_assistant_init();
        }
        return;
    }
    seekfree_assistant_data_analysis();
    apply_parameters();
    now = elapsed_time_ms;
    if(stream_mode != 2 || (uint32)(now - last_send_ms) < send_period_ms)
    {
        return;
    }
    last_send_ms = now;
    wave.channel_num = 8;
    /* 在短临界区中读取控制中断更新的数据，保证各通道快照一致 */
    primask = interrupt_global_disable();
    wave.data[0] = (float)encoder_data_1;
    wave.data[1] = (float)encoder_data_2;
    wave.data[2] = speed_target;
    wave.data[3] = speed_pid_l.out;
    wave.data[4] = speed_pid_r.out;
    interrupt_global_enable(primask);
    wave.data[5] = last_mid_error;
    wave.data[6] = last_servo_angle;
    wave.data[7] = (float)last_threshold;
    seekfree_assistant_oscilloscope_send(&wave);
#endif
}

//-------------------------------------------------------------------------------------------------------------------
// 函数简介     保存待发送的原始灰度图像
// 参数说明     *image          当前摄像头图像首地址
// 返回参数     void
// 备注信息     必须在原地二值化之前调用，只在原始图传到期时复制
//-------------------------------------------------------------------------------------------------------------------
void wifi_assistant_capture_raw(const uint8 *image)
{
#if WIFI_ASSISTANT_ENABLE
    raw_frame_valid = 0;
    if(wifi_assistant_state == WIFI_ASSISTANT_READY && stream_mode == 1 && image_mode == 0 &&
       (uint32)(elapsed_time_ms - last_send_ms) >= send_period_ms)
    {
        memcpy(camera_image, image, sizeof(camera_image));
        raw_frame_valid = 1;
    }
#else
    (void)image;
#endif
}

//-------------------------------------------------------------------------------------------------------------------
// 函数简介     发送当前图像、边线并更新图像调试数据
// 参数说明     *image          处理后图像首地址
// 参数说明     *left / *middle / *right左边线、中线和右边线数组
// 参数说明     mid_error       当前中线偏差
// 参数说明     servo_angle     当前舵机控制角度
// 参数说明     threshold       当前二值化阈值
// 返回参数     void
// 备注信息     主循环完成图像处理后调用；按设定周期发送，避免每帧都占用链路
//-------------------------------------------------------------------------------------------------------------------
void wifi_assistant_on_frame(const uint8 *image, const uint8 *left,
                             const uint8 *middle, const uint8 *right,
                             float mid_error, float servo_angle, uint8 threshold)
{
#if WIFI_ASSISTANT_ENABLE
    uint32 now = elapsed_time_ms;
    last_mid_error = mid_error;
    last_servo_angle = servo_angle;
    last_threshold = threshold;
    if(wifi_assistant_state != WIFI_ASSISTANT_READY || stream_mode != 1 ||
       (uint32)(now - last_send_ms) < send_period_ms)
    {
        return;
    }
    if(image_mode == 0)
    {
        if(!raw_frame_valid)
        {
            return;
        }
        raw_frame_valid = 0;
    }
    else
    {
        memcpy(camera_image, image, sizeof(camera_image));
    }
    memcpy(camera_left, left, sizeof(camera_left));
    memcpy(camera_middle, middle, sizeof(camera_middle));
    memcpy(camera_right, right, sizeof(camera_right));
    last_send_ms = now;
    seekfree_assistant_camera_send();
    if(wifi_assistant_state == WIFI_ASSISTANT_READY)
    {
        ++wifi_assistant_frame_count; // 仅统计图像及边线全部发送成功的完整帧
    }
#else
    (void)image;
    (void)left;
    (void)middle;
    (void)right;
    (void)mid_error;
    (void)servo_angle;
    (void)threshold;
#endif
}
