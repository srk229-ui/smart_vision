#ifndef WIFI_ASSISTANT_H
#define WIFI_ASSISTANT_H

#include "zf_common_typedef.h"
#include "wifi_assistant_config.h"

typedef enum
{
    WIFI_ASSISTANT_DISABLED,
    WIFI_ASSISTANT_INITIALIZING,
    WIFI_ASSISTANT_MODULE_ERROR,
    WIFI_ASSISTANT_LINK_ERROR,
    WIFI_ASSISTANT_READY,
    WIFI_ASSISTANT_SEND_ERROR,
    WIFI_ASSISTANT_WIFI_ERROR // 模块通信正常，但连接热点失败
} wifi_assistant_state_enum;

extern float wifi_assistant_servo_gain;
extern volatile wifi_assistant_state_enum wifi_assistant_state;
/* 调试统计：发送失败次数、最近未发送字节数、自动重连次数及完整图像帧数 */
extern volatile uint32 wifi_assistant_send_error_count;
extern volatile uint32 wifi_assistant_last_unsent_bytes;
extern volatile uint32 wifi_assistant_reconnect_count;
extern volatile uint32 wifi_assistant_frame_count;

/* 在启动电机控制定时器前调用一次，完成模块及逐飞助手接口初始化 */
void wifi_assistant_init(void);
/* 在现有控制定时器中调用，仅更新时间，不执行 SPI 或网络操作 */
void wifi_assistant_tick(uint32 elapsed_ms);
/* 主循环调用，处理参数接收及虚拟示波器发送 */
void wifi_assistant_poll(void);
/* 二值化处理前保存原始图像，供原始灰度图传使用 */
void wifi_assistant_capture_raw(const uint8 *image);
/* 主循环完成图像处理和舵机控制后，发送图像及三条边线 */
void wifi_assistant_on_frame(const uint8 *image, const uint8 *left,
                             const uint8 *middle, const uint8 *right,
                             float mid_error, float servo_angle, uint8 threshold);

#endif
