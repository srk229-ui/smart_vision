"""直接编译真实Wi-Fi服务函数，验证离线诊断不会阻塞邮箱且STOP不丢失。"""

from pathlib import Path
import argparse
import importlib.util
import re
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'tools'))
import run_software_checks as checks

spec = importlib.util.spec_from_file_location('wifi_contract', ROOT / 'drivers/wifi_spi_v2/tests/test_m2_wifi.py')
contract = importlib.util.module_from_spec(spec)
spec.loader.exec_module(contract)

STUB = r'''
#include "control_types.h"
#include "calibration_config.h"
#define WIFI_ASSISTANT_ENABLE 1
#define WIFI_ASSISTANT_RECONNECT_PERIOD_MS 2000
#define WIFI_ASSISTANT_RUNNING_PERIOD_MS 100
#define WIFI_ASSISTANT_SEND_ATTEMPTS 3
#define MT9V03X_H 120
#define MT9V03X_W 188
typedef struct { uint8 channel_num; float data[8]; } seekfree_assistant_oscilloscope_struct;
static wifi_assistant_state_enum wifi_assistant_state;
static uint32 elapsed_time_ms=5000, last_reconnect_ms, last_send_ms, send_period_ms=100;
static uint32 wifi_spi_io_error_count, seekfree_assistant_receive_error_count;
static uint32 wifi_assistant_reconnect_count, wifi_assistant_send_error_count, wifi_assistant_last_unsent_bytes;
static uint32 wifi_assistant_frame_count;
static uint8 width_calibration_request, stop_seen, raw_frame_valid, stream_mode=1, image_mode=1;
static uint8 camera_image[120][188], camera_left[120], camera_middle[120], camera_right[120];
static ControlState state=CONTROL_READY;
static uint32 stop_calls, fault_calls, init_calls, apply_calls, camera_calls, receive_calls;
static uint8 receive_mode, service_running, force_send_error;
ControlState control_get_state(void) { return state; }
void control_request_stop(void) { ++stop_calls; state=CONTROL_READY; }
void control_report_link_fault(void) { ++fault_calls; state=CONTROL_FAULT; }
void control_get_snapshot(ControlSnapshot *out) { memset(out,0,sizeof(*out)); out->state=state; }
void wifi_spi_service_begin(uint8 running) { service_running=running; }
void wifi_spi_service_end(void) { service_running=0; }
uint8 wifi_spi_service_is_running(void) { return service_running; }
uint32 wifi_spi_send_buffer(const uint8 *data,uint32 length) { (void)data; return force_send_error ? length : 0; }
void system_delay_ms(uint32 ms) { (void)ms; }
void show_state(void) {}
void wifi_assistant_init(void) { ++init_calls; }
void seekfree_assistant_receive_reset(void) {}
void seekfree_assistant_data_analysis(void) {
    ++receive_calls;
    assert(service_running == (CALIBRATION_DEBUG_ENABLE || state==CONTROL_RUNNING));
    if(receive_mode) stop_seen=1;
    if(receive_mode==2) ++wifi_spi_io_error_count;
}
void apply_parameters(uint8 running) { (void)running; ++apply_calls; if(stop_seen) control_request_stop(); }
void seekfree_assistant_oscilloscope_send(seekfree_assistant_oscilloscope_struct *wave) { (void)wave; }
void seekfree_assistant_camera_send(void) { ++camera_calls; }
'''

CASES = r'''
int main(void) {
    uint8 image[120*188]={0}, boundary[120]={0};
    uint8 byte=0;
    wifi_assistant_state=WIFI_ASSISTANT_MODULE_ERROR;
    wifi_assistant_poll();
    assert(init_calls==(CALIBRATION_DEBUG_ENABLE ? 0u : 1u));
    assert(state==CONTROL_READY && fault_calls==0);
    wifi_assistant_state=WIFI_ASSISTANT_READY; receive_mode=1;
    wifi_assistant_poll();
    assert(receive_calls==1 && stop_calls==1 && apply_calls==1);
    receive_mode=2; stop_seen=0;
    wifi_assistant_poll();
    assert(stop_calls==2 && stop_seen==0 && apply_calls==1);
    assert(state==CONTROL_READY && fault_calls==0);
    wifi_assistant_state=WIFI_ASSISTANT_READY; force_send_error=1;
    wifi_spi_service_begin(CALIBRATION_DEBUG_ENABLE);
    assert(assistant_send(&byte,1)==1);
    assert(fault_calls==0);
    wifi_assistant_state=WIFI_ASSISTANT_READY; state=CONTROL_RUNNING;
    wifi_spi_service_begin(1); assistant_send(&byte,1);
    assert(fault_calls==1 && state==CONTROL_FAULT);
    state=CONTROL_READY; force_send_error=0; wifi_assistant_state=WIFI_ASSISTANT_READY;
    wifi_assistant_capture_raw(image);
    wifi_assistant_on_frame(image,boundary,boundary,boundary,0,0,0);
    assert(camera_calls==(CALIBRATION_DEBUG_ENABLE ? 0u : 1u));
    puts("PASS actual Wi-Fi diagnostic/normal functions: offline retry, bounded RX, STOP+RX fault, send fault, image gate");
    return 0;
}
'''


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--evidence-dir', required=True, type=Path)
    args = parser.parse_args()
    checks.EVIDENCE = args.evidence_dir.resolve()
    source = (ROOT / 'user/src/wifi_assistant.c').read_text(encoding='utf-8')
    header = (ROOT / 'user/inc/wifi_assistant.h').read_text(encoding='utf-8')
    enum = re.search(r'typedef enum\s*\{[^}]+\}\s*wifi_assistant_state_enum;', header, re.S).group(0)
    functions = '\n'.join(contract.extract_function(source, name) for name in (
        'assistant_send', 'wifi_assistant_poll', 'wifi_assistant_capture_raw', 'wifi_assistant_on_frame'))
    for enabled in (0, 1):
        name = 'test_calibration_wifi_' + str(enabled)
        directory = checks.EVIDENCE / name
        directory.mkdir(parents=True, exist_ok=True)
        generated = directory / (name + '.c')
        generated.write_text(contract.COMMON + enum + STUB + functions + CASES, encoding='utf-8')
        checks.compile_test(name, [generated], ['CALIBRATION_DEBUG_ENABLE=' + str(enabled)])


if __name__ == '__main__':
    main()
