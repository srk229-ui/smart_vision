#include "main.h" // 所有引脚信息更改在main.h里改宏

// *************************** 例程硬件连接说明 ***************************
/*

            连接好电机、主板、驱动板、摄像头、编码器
            (请确保全部正确连接后在使用此例程，所有外设均会使用)
*/
// *************************** 例程测试说明 ***************************
/*
            本例程包含功能：
            1.初始化摄像头并采集图像进行大津法二值化
            2.初始化屏幕并显示关键信息
            3.加权视觉误差、置信度和有界舵机 P/PD 转向
            4.十毫秒双轮 PI、上电停止、人工启动与故障锁存


            注意！注意！注意！注意！
            注意！注意！注意！注意！
            注意！注意！注意！注意！

            1.请仔细阅读main.h的所有注释，确保所有宏都和自己的硬件连接对应
            2.若屏幕显示二值化后的图像有缺陷，可能不能正常走直线，
            可以自行更改二值化算法或找光环境良好且均匀的环境测试例程（例程不提供更多的二值化算法）

*/

// **************************** 代码区域 ****************************

// 舵机中位采用现有配置作为初始值，实车仍需人工标定。
const float servo_motor_duty_middle = SERVO_MOTOR_CENTER;

static uint8_t image[MT9V03X_H][MT9V03X_W]; // main持有的完整快照，先灰度后原地二值化；不直接在DMA缓冲上计算。
static uint32_t hist_gram[256]; // 256灰度桶，32位统计，由每帧直方图函数完整清零。
static VisionResult vision; // 本帧边线/质量/误差；数组为static，避免在中断/栈上放120行结果。

//-------------------------------------------------------------------------------------------------------------------
// 函数简介     初始化外设与控制层，上电保持 READY 和零输出
// 参数说明     void
// 返回参数     void
// 备注信息     联网和相机等待不启动电机；人工确认后才允许运行
//-------------------------------------------------------------------------------------------------------------------
void Init(void)
{
    // 1. 先以零占空比启动PWM外设，后面的联网/相机重试不会因此直接发车。
    /* 电机与舵机 */
    pwm_init(MOTOR1_PWM, 17000, 0); // 左电机17kHz载波由硬件生成，最后参数0表示上电零命令。
    gpio_init(MOTOR1_DIR, GPO, MOTOR1_FORWARD_DIR_LEVEL, GPO_PUSH_PULL);
    pwm_init(MOTOR2_PWM, 17000, 0); // 右轮独立通道，前进方向电平须在main.h按实车标定。
    gpio_init(MOTOR2_DIR, GPO, MOTOR2_FORWARD_DIR_LEVEL, GPO_PUSH_PULL);
    pwm_init(SERVO_MOTOR_PWM, SERVO_MOTOR_FREQ, 0); // 50Hz/20ms硬件脉冲，上电为0，不立即输出中位脉宽。

    // 2. 在PIT启动前安装保存/恢复PRIMASK钩子，配置控制和两路编码器，保证首轮也能安全读写共享状态。
    /* 控制与编码器 */
    control_set_critical_hooks(interrupt_global_disable, interrupt_global_enable);
    control_init(servo_motor_duty_middle,
                 MIN(SERVO_MOTOR_L_MAX, SERVO_MOTOR_R_MAX),
                 MAX(SERVO_MOTOR_L_MAX, SERVO_MOTOR_R_MAX), SERVO_DIR);
    control_set_output_enabled(MOTOR_ENABLE, SERVO_MOTOR_ENABLE); // 编译许可仍需人工确认、正目标和模式条件才能起车。
    encoder_quad_init(ENCODER_1, ENCODER_1_A, ENCODER_1_B);
    encoder_quad_init(ENCODER_2, ENCODER_2_A, ENCODER_2_B);
    pit_ms_init(PIT_CH0, CONTROL_LOOP_PERIOD_MS); // 固定10ms；startup已开IRQ，控制可早于后续联网/相机完成运行。

    // 3. 显示/网络初始化在main上下文执行，不能放入速度控制ISR。
    /* 显示与通信 */
    flash_init();
    tft180_init();
    wifi_assistant_init();

    // 4. 相机初始化失败就在停止状态重试；成功后包装原回调，保留SDK双缓冲，再复位视觉时间历史。
    /* 摄像头 */
    while (mt9v03x_init())
    {
        tft180_show_string(0, 16, "CAM RETRY");
        system_delay_ms(1000);
    }
    camera_frame_install();
    vision_reset();
    tft180_show_string(0, 16, "READY / STOP");
}

// 静止、居中的直道图像才能用于宽度标定，不能从合成默认值推断实车宽度。
static uint8_t calibrate_width(const ControlParams *params, const ControlSnapshot *snapshot)
{
    uint16_t row;
    uint16_t widths[CONTROL_IMAGE_HEIGHT]; // 先收集全组候选，避免控制行失败时已写入一部分参考宽度。
    uint8_t i;
    // 1. 只在不运行且左右读数接近0时标定；零PWM不代表轮子已停，因此另查编码器。
    if (snapshot->state == CONTROL_RUNNING || snapshot->measured_left < -1 ||
        snapshot->measured_left > 1 || snapshot->measured_right < -1 || snapshot->measured_right > 1 ||
        // 图像须可用/高可信，误差在±5像素内，即人工居中直道，不能拿偏斜单边图标定宽度。
        !vision.valid || vision.confidence < 0.9f || vision.error_px < -5.0f || vision.error_px > 5.0f ||
        (uint32_t)(control_now_ms() - vision.capture_time_ms) > 100u) return 0u;
    // 2. 按左右边坐标差记录实测宽度，虚拟重建或太窄白斑清为0；0表示该行未标定。
    for (row = 0; row < CONTROL_IMAGE_HEIGHT; ++row)
    {
        uint16_t width = (uint16_t)(vision.right[row] - vision.left[row]); // 坐标差，不是白像素个数；3白像素只得到宽度2。
        widths[row] = vision.row_quality[row] == 2u && width >= 3u && width < CONTROL_IMAGE_WIDTH ? width : 0u;
    }
    // 3. 五个控制行必须都有合格的双边实测宽度；其他行可为0，不要求全图120行皆有效。
    for (i = 0; i < CONTROL_BAND_COUNT; ++i)
        if (widths[params->look_rows[i]] == 0u) return 0u;
    // 4. 全组校验通过再提交，并核对每次setter的返回；宽度被拒绝时不能显示OK。
    for (row = 0; row < CONTROL_IMAGE_HEIGHT; ++row)
        if (!vision_set_reference_width(row, widths[row])) return 0u;
    vision_reset(); // 保留刚提交的宽度，只清视觉种子/时间历史；不自动发车或代替人工确认。
    return 1u;
}

int main(void)
{
    uint32_t band_version = 0u; // 视觉已安装的参数版本；初始0保证第一轮配置五行控制带。
    uint32_t last_display_ms = 0u; // 停车显示上次刷新时刻，200逻辑ms限频以免挤占视觉处理。
    uint32_t calibration_request_ms = 0u; // 等新图宽度请求的起点，1秒仍无帧则取消。
    uint8_t calibration_pending = 0u; // 请求只准备一次标定，首个新帧给出OK/REJECTED，不循环自动接受。
    clock_init(SYSTEM_CLOCK_600M); // 设置CPU时钟与中断分组；实际抖动不能据600MHz配置推断。
    debug_init();
    system_delay_ms(300);
    Init();
    interrupt_global_enable(0); // 确认主循环IRQ开放；并非此处才第一次启用Init中已启动的PIT。

    while (1)
    {
        ControlParams params;
        ControlSnapshot snapshot;
        uint32_t version;
        uint32_t frame_id;
        uint32_t capture_ms;
        // 1. 参数/版本同锁复制；控制带只在新版本安装成功后记录，失败则锁接口故障。
        control_get_params(&params, &version);
        if (version != band_version)
        {
            if (vision_set_control_band(params.look_rows, params.look_weights)) band_version = version; // 不把失败版本记成已生效。
            else control_report_invalid_fault();
        }
        // 人工请求由poll锁存、下一轮领取；仅登记待标定，不触发电机或舵机启动。
        if (wifi_assistant_take_width_calibration_request())
        {
            calibration_pending = 1u;
            calibration_request_ms = control_now_ms();
        }
        // 优先处理新帧，显示和网络不得抢在视觉与控制目标发布之前。
        // 2. 只处理成功复制的新帧；没有新图时PIT仍继续查图像年龄，main不伪造新结果。
        if (camera_frame_take((uint8_t *)image, &frame_id, &capture_ms))
        {
            uint8_t threshold;
            wifi_assistant_capture_raw((const uint8 *)image); // 二值化前保存原灰度；应用内部仅在允许停车图传时复制。
            get_hist_gram((uint8_t *)image, MT9V03X_H, MT9V03X_W, hist_gram); // 全图256桶计数，每帧重新构造。
            threshold = get_threshold_otsu(hist_gram); // 求当前图类间方差最大阈值，纯色/空输入在算法内处理。
            binaryzation_process((uint8_t *)image, MT9V03X_H, MT9V03X_W, threshold); // 原地转0/255，边线判断不再依赖灰度阈值。
            // 寻线模块只读二值图，按新帧号/采集时间生成质量与误差；阈值由本调用层补入诊断字段。
            vision_process((uint8_t *)image, frame_id, capture_ms, &vision);
            vision.threshold = threshold;
            control_publish_vision(&vision); // 更新图像资格与P/PD目标；PI和舵机限速/实际PWM写入仍在PIT。
            control_get_snapshot(&snapshot); // 原子取当下状态；最近tick输出与最新视觉字段可能来自不同时间域。
            // 3. 人工宽度请求仅用这次新帧尝试一次；不符合静止/居中条件则显式拒绝。
            if (calibration_pending)
            {
                uint8_t accepted = calibrate_width(&params, &snapshot);
                calibration_pending = 0u; // 消费请求，失败不会在后续另一张图上悄悄自动成功。
                printf("[vision] width calibration %s\r\n", accepted ? "OK" : "REJECTED");
            }
            // 4. 仅停车显示，200逻辑ms最多一次；行驶把CPU机会留给新帧和有界通信。
            if (snapshot.state != CONTROL_RUNNING &&
                (uint32_t)(control_now_ms() - last_display_ms) >= 200u)
            {
                last_display_ms = control_now_ms();
                tft180_displayimage03x((uint8_t *)image, 125, 100);
                tft180_show_int(0, 0, snapshot.measured_left, 3);
                tft180_show_int(0, 30, snapshot.measured_right, 3);
                tft180_show_float(0, 50, snapshot.confidence, 1, 2);
                tft180_show_int(0, 70, (int32)snapshot.fault, 2);
            }
            // 图传使用独立边线数组，不在二值图上涂线；接口内部按运行状态禁止行驶发送整图。
            wifi_assistant_on_frame((const uint8 *)image, vision.left, vision.middle, vision.right,
                                    vision.error_px, snapshot.servo_cmd, threshold);
        }
        // 5. 始终无新帧时取消待标定，避免旧请求在很久后的错误工况下才被执行。
        if (calibration_pending && (uint32_t)(control_now_ms() - calibration_request_ms) > 1000u)
        {
            calibration_pending = 0u;
            printf("[vision] width calibration NO NEW FRAME\r\n");
        }
        wifi_assistant_poll(); // 主循环最后收发；运行路径有截止预算，重连/整图续传仅在停车路径。
    }
}
